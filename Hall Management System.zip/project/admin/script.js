document.addEventListener('DOMContentLoaded', function() {
    // Sidebar Toggle Functionality
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
    const mainContent = document.querySelector('.main-content');
    
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            mainContent.classList.toggle('shifted');
        });
    }
    
    if (sidebarToggleBtn) {
        sidebarToggleBtn.addEventListener('click', function() {
            sidebar.classList.toggle('show');
            mainContent.classList.toggle('shifted');
        });
    }
    
    // Initialize FullCalendar with enhanced styling
    const calendarEl = document.getElementById('bookingCalendar');
    if (calendarEl) {
        const calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            themeSystem: 'bootstrap5',
            dayMaxEventRows: 3,
            events: [
                {
                    title: 'Wedding Booking',
                    start: '2023-10-15',
                    end: '2023-10-16',
                    color: '#4cc9f0',
                    textColor: 'white'
                },
                {
                    title: 'Corporate Event',
                    start: '2023-10-14',
                    end: '2023-10-14',
                    color: '#4361ee',
                    textColor: 'white'
                },
                {
                    title: 'Birthday Party',
                    start: '2023-10-12',
                    end: '2023-10-12',
                    color: '#f8961e',
                    textColor: 'white'
                },
                {
                    title: 'Team Meeting',
                    start: '2023-10-10',
                    end: '2023-10-10',
                    color: '#4361ee',
                    textColor: 'white'
                },
                {
                    title: 'Cancelled Booking',
                    start: '2023-10-08',
                    end: '2023-10-08',
                    color: '#f94144',
                    textColor: 'white'
                },
                {
                    title: 'Hall Maintenance',
                    start: '2023-10-05',
                    end: '2023-10-06',
                    color: '#6c757d',
                    textColor: 'white'
                }
            ],
            eventClick: function(info) {
                const eventType = info.event.backgroundColor === '#f94144' ? 'Cancelled' : 
                                 info.event.backgroundColor === '#f8961e' ? 'Pending' : 
                                 info.event.backgroundColor === '#6c757d' ? 'Maintenance' : 'Confirmed';
                
                const modalHtml = `
                    <div class="modal fade" id="eventModal" tabindex="-1" aria-labelledby="eventModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header" style="background-color: ${info.event.backgroundColor}; color: white;">
                                    <h5 class="modal-title" id="eventModalLabel">${info.event.title}</h5>
                                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <strong>Status:</strong> <span class="badge" style="background-color: ${info.event.backgroundColor}">${eventType}</span>
                                    </div>
                                    <div class="mb-3">
                                        <strong>Date:</strong> ${info.event.start.toLocaleDateString()} ${info.event.end ? 'to ' + info.event.end.toLocaleDateString() : ''}
                                    </div>
                                    <div class="mb-3">
                                        <strong>Hall:</strong> ${info.event.title.includes('Wedding') ? 'Grand Ballroom' : 
                                                              info.event.title.includes('Corporate') ? 'Conference Hall' : 
                                                              info.event.title.includes('Birthday') ? 'Birthday Hall' : 'Meeting Room'}
                                    </div>
                                    <div class="mb-3">
                                        <strong>Amount:</strong> ₹${info.event.title.includes('Wedding') ? '42,500' : 
                                                              info.event.title.includes('Corporate') ? '25,000' : 
                                                              info.event.title.includes('Birthday') ? '18,000' : '8,500'}
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">View Details</button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                document.body.insertAdjacentHTML('beforeend', modalHtml);
                const eventModal = new bootstrap.Modal(document.getElementById('eventModal'));
                eventModal.show();
                
                document.getElementById('eventModal').addEventListener('hidden.bs.modal', function() {
                    this.remove();
                });
                
                info.jsEvent.preventDefault();
            }
        });
        calendar.render();
    }
    
    // Initialize ApexCharts
    // Combined Booking & Revenue Chart
    const combinedChartOptions = {
        series: [{
            name: 'Bookings',
            type: 'column',
            data: [12, 19, 15, 22, 18, 25, 30, 28, 32, 24, 30, 35]
        }, {
            name: 'Revenue',
            type: 'line',
            data: [24000, 38000, 30000, 44000, 36000, 50000, 60000, 56000, 64000, 48000, 60000, 70000]
        }],
        chart: {
            height: 350,
            type: 'line',
            stacked: false,
            toolbar: {
                show: false
            },
            fontFamily: 'Inter, sans-serif'
        },
        stroke: {
            width: [0, 3],
            curve: 'smooth'
        },
        plotOptions: {
            bar: {
                columnWidth: '50%',
                borderRadius: 5
            }
        },
        colors: ['#4361ee', '#4cc9f0'],
        fill: {
            opacity: [0.85, 1],
        },
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        xaxis: {
            type: 'category',
            labels: {
                style: {
                    fontSize: '12px'
                }
            }
        },
        yaxis: [{
            seriesName: 'Bookings',
            axisTicks: {
                show: true,
            },
            axisBorder: {
                show: true,
            },
            title: {
                text: "Bookings",
                style: {
                    color: '#4361ee',
                    fontSize: '12px'
                }
            },
            labels: {
                style: {
                    fontSize: '12px'
                },
                formatter: function(val) {
                    return val.toFixed(0);
                }
            }
        }, {
            seriesName: 'Revenue',
            opposite: true,
            axisTicks: {
                show: true,
            },
            axisBorder: {
                show: true,
                color: '#4cc9f0'
            },
            title: {
                text: "Revenue (₹)",
                style: {
                    color: '#4cc9f0',
                    fontSize: '12px'
                }
            },
            labels: {
                style: {
                    fontSize: '12px'
                },
                formatter: function(val) {
                    return '₹' + val.toLocaleString('en-IN');
                }
            }
        }],
        tooltip: {
            shared: true,
            intersect: false,
            style: {
                fontSize: '13px'
            },
            y: {
                formatter: function (y) {
                    if (typeof y !== "undefined") {
                        return y.toLocaleString('en-IN') + (y === 1 ? " booking" : " bookings");
                    }
                    return y;