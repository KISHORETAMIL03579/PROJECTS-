// Category Filter Functionality
document.addEventListener('DOMContentLoaded', () => {
    const categoryTabs = document.querySelectorAll('.category-tab');
    const hallCards = document.querySelectorAll('.hall-card');

    categoryTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Remove active class from all tabs
            categoryTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            tab.classList.add('active');

            const category = tab.textContent.trim().toLowerCase();
            
            // Show all halls if "All Venues" is selected
            if (category === 'all venues') {
                hallCards.forEach(card => {
                    card.style.display = 'block';
                    // Add fade-in animation
                    card.style.opacity = '0';
                    setTimeout(() => {
                        card.style.opacity = '1';
                    }, 50);
                });
                return;
            }

            // Filter halls based on category
            hallCards.forEach(card => {
                const hallType = card.querySelector('.hall-type').textContent.toLowerCase();
                if (hallType === category) {
                    card.style.display = 'block';
                    // Add fade-in animation
                    card.style.opacity = '0';
                    setTimeout(() => {
                        card.style.opacity = '1';
                    }, 50);
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });

    // Hall Card Actions
    const actionButtons = document.querySelectorAll('.action-button');
    
    actionButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const action = e.currentTarget.querySelector('i').classList[1];
            const hallCard = button.closest('.hall-card');
            const hallName = hallCard.querySelector('.hall-name').textContent;

            switch(action) {
                case 'fa-eye':
                    viewHallDetails(hallName);
                    break;
                case 'fa-edit':
                    editHall(hallName);
                    break;
                case 'fa-trash':
                    deleteHall(hallName, hallCard);
                    break;
            }
        });
    });
});

// View Hall Details
function viewHallDetails(hallName) {
    console.log(`Viewing details for ${hallName}`);
    // Implement view functionality
}

// Edit Hall
function editHall(hallName) {
    console.log(`Editing ${hallName}`);
    // Implement edit functionality
}

// Delete Hall
function deleteHall(hallName, hallCard) {
    if (confirm(`Are you sure you want to delete ${hallName}?`)) {
        hallCard.style.opacity = '0';
        setTimeout(() => {
            hallCard.style.display = 'none';
        }, 300);
        console.log(`Deleted ${hallName}`);
    }
}

// Add smooth transitions for hall cards
document.querySelectorAll('.hall-card').forEach(card => {
    card.style.transition = 'opacity 0.3s ease';
}); 