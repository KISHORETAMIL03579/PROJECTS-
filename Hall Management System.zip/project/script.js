// Sample data for demonstration
let halls = [
    {
        id: 1,
        name: "Grand Wedding Hall",
        type: "Wedding",
        capacity: 250,
        location: "Main Building",
        price: 15000,
        status: "Available",
        image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?ixlib=rb-4.0.3",
        amenities: ["WiFi", "Projector", "Sound System"]
    },
    {
        id: 2,
        name: "Corporate Conference Center",
        type: "Conference",
        capacity: 100,
        location: "East Wing, Business Park",
        price: 8000,
        status: "Available",
        image: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?ixlib=rb-4.0.3",
        amenities: ["WiFi", "Projector", "Whiteboard"]
    },
    {
        id: 3,
        name: "Celebration Party Hall",
        type: "Party",
        capacity: 150,
        location: "South Entertainment District",
        price: 12000,
        status: "Available",
        image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?ixlib=rb-4.0.3",
        amenities: ["WiFi", "Stage", "Professional Sound System"]
    },
    {
        id: 4,
        name: "Skyline Rooftop Venue",
        type: "Rooftop",
        capacity: 200,
        location: "Downtown",
        price: 20000,
        status: "Available",
        image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3?ixlib=rb-4.0.3",
        amenities: ["WiFi", "Bar", "Outdoor Seating"]
    }
];

let bookings = [
    {
        id: "BK001",
        hallId: 1,
        hallName: "Grand Wedding Hall",
        category: "Wedding",
        userName: "John Doe",
        date: "2024-03-15",
        startTime: "09:00",
        endTime: "17:00",
        status: "Pending",
        amount: 15000
    },
    {
        id: "BK002",
        hallId: 2,
        hallName: "Corporate Conference Center",
        category: "Conference",
        userName: "Jane Smith",
        date: "2024-03-16",
        startTime: "10:00",
        endTime: "16:00",
        status: "Approved",
        amount: 8000
    },
    {
        id: "BK003",
        hallId: 3,
        hallName: "Executive Meeting Suite",
        category: "Meeting",
        userName: "Mike Johnson",
        date: "2024-03-14",
        startTime: "14:00",
        endTime: "16:00",
        status: "Rejected",
        amount: 5000
    }
];

// Sample users data
const users = [
    {
        id: 1,
        name: "Admin User",
        username: "@admin",
        email: "admin@example.com",
        role: "Admin",
        status: "Active",
        joinedDate: "April 9, 2025",
        avatar: "AU"
    },
    {
        id: 2,
        name: "John Doe",
        username: "@johndoe",
        email: "john@example.com",
        role: "User",
        status: "Active",
        joinedDate: "April 8, 2025",
        avatar: "JD"
    },
    {
        id: 3,
        name: "Jane Smith",
        username: "@janesmith",
        email: "jane@example.com",
        role: "User",
        status: "Inactive",
        joinedDate: "April 7, 2025",
        avatar: "JS"
    }
];

// Sample announcements array
const announcements = [];

// Sample feedback data
const feedbacks = [];

// DOM Elements
const navLinks = document.querySelectorAll('.nav-links li a');
const sections = document.querySelectorAll('.section');
const modal = document.getElementById('addHallModal');
const closeBtn = document.querySelector('.close');
const addHallForm = document.getElementById('addHallForm');

// Navigation
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href').substring(1);
        
        // Update active nav link
        navLinks.forEach(l => l.parentElement.classList.remove('active'));
        link.parentElement.classList.add('active');
        
        // Show target section
        sections.forEach(section => {
            section.classList.remove('active');
            if (section.id === targetId) {
                section.classList.add('active');
            }
        });
    });
});

// Modal Functions
function showAddHallForm() {
    modal.style.display = 'block';
}

function closeModal() {
    modal.style.display = 'none';
}

closeBtn.addEventListener('click', closeModal);
window.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});

// Form Submission
document.getElementById('addHallForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Get selected amenities
    const selectedAmenities = Array.from(document.querySelectorAll('input[name="amenities"]:checked'))
        .map(checkbox => checkbox.value);
    
    const formData = {
        name: document.getElementById('hallName').value,
        type: document.getElementById('hallType').value,
        capacity: parseInt(document.getElementById('capacity').value),
        location: document.getElementById('location').value,
        price: parseInt(document.getElementById('price').value),
        image: document.getElementById('imageUrl').value,
        status: "Available",
        amenities: selectedAmenities
    };

    const editId = this.getAttribute('data-edit-id');
    
    if (editId) {
        // Edit existing hall
        const index = halls.findIndex(h => h.id === parseInt(editId));
        if (index !== -1) {
            // Preserve the hall ID when updating
            formData.id = parseInt(editId);
            halls[index] = { ...halls[index], ...formData };
            
            // Update the specific hall card in the DOM
            const hallCard = document.querySelector(`[data-hall-id="${editId}"]`);
            if (hallCard) {
                updateHallCard(hallCard, halls[index]);
                showSuccessMessage('Hall updated successfully!');
            }
        }
        this.removeAttribute('data-edit-id');
    } else {
        // Add new hall
        formData.id = halls.length + 1;
        halls.push(formData);
        renderHalls(); // Re-render for new hall
        showSuccessMessage('New hall added successfully!');
    }

    // Close modal and reset form
    document.getElementById('addHallModal').style.display = 'none';
    this.reset();

    // Clear image preview
    const imagePreview = document.querySelector('.image-preview');
    if (imagePreview) {
        imagePreview.style.display = 'none';
        imagePreview.style.backgroundImage = '';
    }

    // Update category counts
    const activeCategory = document.querySelector('.category-tab.active');
    if (activeCategory) {
        filterHallsByCategory(activeCategory.textContent.trim().toLowerCase());
    }
});

// Render Functions
function renderHalls() {
    const hallsGrid = document.querySelector('.halls-grid');
    if (!hallsGrid) return;

    hallsGrid.innerHTML = '';
    
    // Add the Create New Hall card first
    const createHallCard = document.createElement('div');
    createHallCard.className = 'hall-card create-hall';
    createHallCard.innerHTML = `
        <div class="create-hall-content" onclick="showAddHallForm()">
            <div class="create-icon">
                <i class="fas fa-plus"></i>
            </div>
            <h3>Create New Hall</h3>
            <p>Add a new venue to your collection</p>
        </div>
    `;
    hallsGrid.appendChild(createHallCard);
    
    // Render existing halls
    halls.forEach(hall => {
        const hallCard = document.createElement('div');
        hallCard.className = 'hall-card';
        hallCard.setAttribute('data-hall-id', hall.id);
        hallCard.setAttribute('data-type', hall.type.toLowerCase());
        
        hallCard.innerHTML = `
            <div class="hall-image">
                <img src="${hall.image}" alt="${hall.name}">
                <span class="hall-status ${hall.status.toLowerCase()}">${hall.status}</span>
                <div class="hall-type-price">
                    <span class="hall-type">${hall.type}</span>
                    <span class="hall-price">₹${hall.price}/hr</span>
                </div>
            </div>
            <div class="hall-info">
                <h3 class="hall-name">${hall.name}</h3>
                <div class="hall-location">
                </div>
                <i class="fas fa-map-marker-alt"></i>
                ${hall.location}
            </div>
            <div class="hall-capacity">
                <i class="fas fa-users"></i>
                ${hall.capacity} people
            </div>
            <div class="hall-amenities">
                ${hall.amenities.map(amenity => `
                    <span class="amenity-tag">${amenity}</span>
                `).join('')}
            </div>
            <div class="hall-actions">
                <button class="action-button view">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="action-button edit" onclick="openEditModal(${hall.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-button delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        hallsGrid.appendChild(hallCard);
    });

    // Initialize with all venues count
    updateHallsCount('all venues');
}

function renderBookings() {
    const bookingTableBody = document.querySelector('.bookings-table tbody');
    if (!bookingTableBody) return;
    
    bookingTableBody.innerHTML = '';
    
    bookings.forEach(booking => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${booking.id}</td>
            <td>${booking.hallName}</td>
            <td>${booking.category}</td>
            <td>${booking.userName}</td>
            <td>${booking.date} ${booking.startTime} - ${booking.endTime}</td>
            <td>
                <span class="status-badge ${booking.status.toLowerCase()}">
                    <i class="fas fa-circle"></i>
                    ${booking.status}
                </span>
            </td>
            <td>₹${booking.amount}</td>
            <td>
                <div class="table-actions">
                    <button class="action-btn view" onclick="viewBooking('${booking.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    ${booking.status === 'Pending' ? `
                        <button class="action-btn approve" onclick="approveBooking('${booking.id}')">
                            <i class="fas fa-check"></i>
                        </button>
                        <button class="action-btn reject" onclick="rejectBooking('${booking.id}')">
                            <i class="fas fa-times"></i>
                        </button>
                    ` : ''}
                    <button class="action-btn delete" onclick="deleteBooking('${booking.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
            </div>
            </td>
        `;
        bookingTableBody.appendChild(row);
    });
}

// Hall Management Functions
function editHall(button) {
    const card = button.closest('.hall-card');
    const hallName = card.querySelector('.hall-name').textContent;
    const hallType = card.querySelector('.hall-type').textContent;
    const hallPrice = card.querySelector('.hall-price').textContent;
    const hallLocation = card.querySelector('.hall-location span').textContent;
    const hallCapacity = card.querySelector('.hall-capacity span').textContent;
    
    // Open edit modal with current values
    const modal = document.getElementById('addHallModal');
    modal.style.display = 'block';
    
    // Fill form with current values
    document.getElementById('hallName').value = hallName;
    document.getElementById('hallType').value = hallType;
    document.getElementById('price').value = hallPrice.replace('₹', '').replace('/hr', '');
    document.getElementById('location').value = hallLocation;
    document.getElementById('capacity').value = hallCapacity.replace(' people', '');
    
    // Store the card reference
    modal.dataset.editingCard = card.id;
    
    // Update form submit handler
    const form = document.getElementById('addHallForm');
    form.onsubmit = function(e) {
        e.preventDefault();
        
        // Get the card being edited
        const cardToUpdate = document.getElementById(modal.dataset.editingCard);
        
        // Update card with new values
        cardToUpdate.querySelector('.hall-name').textContent = document.getElementById('hallName').value;
        cardToUpdate.querySelector('.hall-type').textContent = document.getElementById('hallType').value;
        cardToUpdate.querySelector('.hall-price').textContent = '₹' + document.getElementById('price').value + '/hr';
        cardToUpdate.querySelector('.hall-location span').textContent = document.getElementById('location').value;
        cardToUpdate.querySelector('.hall-capacity span').textContent = document.getElementById('capacity').value + ' people';
        
        // Update the data-hall-type attribute
        cardToUpdate.setAttribute('data-hall-type', document.getElementById('hallType').value);
        
        // Close modal
        modal.style.display = 'none';
        
        // Reset form
        form.reset();
        
        // Remove the editing card reference
        delete modal.dataset.editingCard;
    };
}

function deleteHall(id) {
    if (confirm('Are you sure you want to delete this hall?')) {
        halls = halls.filter(h => h.id !== id);
        renderHalls();
    }
}

// Booking Management Functions
function approveBooking(id) {
    const booking = bookings.find(b => b.id === id);
    if (booking) {
        booking.status = 'Approved';
        const hall = halls.find(h => h.id === booking.hallId);
        if (hall) {
            hall.status = 'Booked';
        }
        renderBookings();
        showSuccessMessage('Booking approved successfully!');
    }
}

function rejectBooking(id) {
    const booking = bookings.find(b => b.id === id);
    if (booking) {
        booking.status = 'Rejected';
        const hall = halls.find(h => h.id === booking.hallId);
        if (hall) {
            hall.status = 'Available';
        }
        renderBookings();
        showSuccessMessage('Booking rejected successfully!');
    }
}

// Handle category filtering
document.addEventListener('DOMContentLoaded', function() {
    // Get category tabs and initialize halls
        renderHalls();
    
    const categoryTabs = document.querySelectorAll('.category-tab');
    
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            categoryTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');

            const selectedCategory = this.textContent.trim().toLowerCase();
            filterHallsByCategory(selectedCategory);
        });
    });
});

// Function to filter halls by category
function filterHallsByCategory(category) {
    const hallCards = document.querySelectorAll('.hall-card');
    const normalizedCategory = category.toLowerCase().trim();
    
    hallCards.forEach(card => {
        // Skip the "Create New Hall" card
        if (card.classList.contains('create-hall')) {
            return;
        }

        const hallType = card.querySelector('.hall-type').textContent.toLowerCase().trim();
        
        if (normalizedCategory === 'all venues') {
            // Show all halls with a fade-in animation
            card.style.display = 'block';
            card.style.opacity = '0';
            setTimeout(() => {
                card.style.transition = 'opacity 0.3s ease';
                card.style.opacity = '1';
            }, 50);
        } else {
            if (hallType === normalizedCategory) {
                // Show matching halls with a fade-in animation
                card.style.display = 'block';
                card.style.opacity = '0';
                setTimeout(() => {
                    card.style.transition = 'opacity 0.3s ease';
                    card.style.opacity = '1';
                }, 50);
            } else {
                // Hide non-matching halls with a fade-out animation
                card.style.transition = 'opacity 0.3s ease';
                card.style.opacity = '0';
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        }
    });

    // Update halls count
    updateHallsCount(normalizedCategory);
}

// Function to update halls count
function updateHallsCount(category) {
    const hallsGrid = document.querySelector('.halls-grid');
    const visibleHalls = category === 'all venues' 
        ? halls.length 
        : halls.filter(hall => hall.type.toLowerCase() === category).length;
    
    // Create or update the halls count element
    let countElement = document.querySelector('.halls-count');
    if (!countElement) {
        countElement = document.createElement('div');
        countElement.className = 'halls-count';
        hallsGrid.parentElement.insertBefore(countElement, hallsGrid);
    }
    
    countElement.innerHTML = `
        <div class="count-info">
            <span class="count-number">${visibleHalls}</span>
            <span class="count-text">${category === 'all venues' ? 'Total Halls' : `${category.charAt(0).toUpperCase() + category.slice(1)} Halls`}</span>
        </div>
    `;
}

// Handle hall actions
document.addEventListener('DOMContentLoaded', function() {
    // View hall details
    document.querySelectorAll('.action-button.view').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const hallCard = this.closest('.hall-card');
            const hallName = hallCard.querySelector('.hall-name').textContent;
            // Add your view hall logic here
            console.log('Viewing hall:', hallName);
        });
    });

    // Edit hall details
    document.querySelectorAll('.action-button.edit').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const hallCard = this.closest('.hall-card');
            const hallName = hallCard.querySelector('.hall-name').textContent;
            // Add your edit hall logic here
            console.log('Editing hall:', hallName);
        });
    });

    // Delete hall
    document.querySelectorAll('.action-button.delete').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const hallCard = this.closest('.hall-card');
            const hallName = hallCard.querySelector('.hall-name').textContent;
            if (confirm(`Are you sure you want to delete ${hallName}?`)) {
                // Add your delete hall logic here
                console.log('Deleting hall:', hallName);
            }
        });
    });
});

// Function to open edit modal
function openEditModal(hallId) {
    const hall = halls.find(h => h.id === hallId);
    if (!hall) return;

    const modal = document.getElementById('addHallModal');
    const modalTitle = modal.querySelector('h2');
    const form = document.getElementById('addHallForm');

    modalTitle.textContent = 'Edit Hall';
    
    // Populate form fields
    form.elements['hallName'].value = hall.name;
    form.elements['hallType'].value = hall.type;
    form.elements['capacity'].value = hall.capacity;
    form.elements['location'].value = hall.location;
    form.elements['price'].value = hall.price;
    form.elements['imageUrl'].value = hall.image;
    
    // Handle amenities checkboxes
    const amenityCheckboxes = form.querySelectorAll('input[name="amenities"]');
    amenityCheckboxes.forEach(checkbox => {
        checkbox.checked = hall.amenities.includes(checkbox.value);
    });
    
    // Set form data attribute for edit mode
    form.setAttribute('data-edit-id', hallId);
    
    // Show preview of current image
    const imagePreview = document.querySelector('.image-preview');
    if (imagePreview) {
        imagePreview.style.display = 'block';
        imagePreview.style.backgroundImage = `url(${hall.image})`;
    }
    
    modal.style.display = 'block';
}

// Function to show success message
function showSuccessMessage(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    document.body.appendChild(successDiv);
    
    // Remove the message after 3 seconds
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

// Delete hall functionality
document.addEventListener('click', function(e) {
    if (e.target.closest('.action-button.delete')) {
        const hallCard = e.target.closest('.hall-card');
        const hallId = parseInt(hallCard.getAttribute('data-hall-id'));
        
        if (confirm('Are you sure you want to delete this hall?')) {
            // Remove from the halls array
            halls = halls.filter(h => h.id !== hallId);
            
            // Add fade-out animation
            hallCard.style.transition = 'opacity 0.3s ease';
            hallCard.style.opacity = '0';
            
            // Remove the card after animation
            setTimeout(() => {
                hallCard.remove();
                // Update the halls count
                updateHallsCount('all venues');
                showSuccessMessage('Hall deleted successfully!');
            }, 300);
        }
    }
});

// Function to update a specific hall card
function updateHallCard(cardElement, hallData) {
    // Completely replace the card's content
    cardElement.innerHTML = `
        <div class="hall-image">
            <img src="${hallData.image}" alt="${hallData.name}">
            <span class="hall-status ${hallData.status.toLowerCase()}">${hallData.status}</span>
            <div class="hall-type-price">
                <span class="hall-type">${hallData.type}</span>
                <span class="hall-price">₹${hallData.price}/hr</span>
            </div>
        </div>
        <div class="hall-info">
            <h3 class="hall-name">${hallData.name}</h3>
            <div class="hall-location">
                <i class="fas fa-map-marker-alt"></i>
                ${hallData.location}
            </div>
            <div class="hall-capacity">
                <i class="fas fa-users"></i>
                ${hallData.capacity} people
            </div>
            <div class="hall-amenities">
                ${hallData.amenities.map(amenity => `
                    <span class="amenity-tag">${amenity}</span>
                `).join('')}
            </div>
            <div class="hall-actions">
                <button class="action-button view">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="action-button edit" onclick="openEditModal(${hallData.id})">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-button delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;

    // Add animation to show the update
    cardElement.style.animation = 'none';
    cardElement.offsetHeight; // Trigger reflow
    cardElement.style.animation = 'updateGlow 0.5s ease-in-out';

    // Reattach event listeners for the new buttons
    const deleteButton = cardElement.querySelector('.action-button.delete');
    if (deleteButton) {
        deleteButton.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete this hall?')) {
                // Remove from the halls array
                halls = halls.filter(h => h.id !== hallData.id);
                
                // Add fade-out animation
                cardElement.style.transition = 'opacity 0.3s ease';
                cardElement.style.opacity = '0';
                
                // Remove the card after animation
                setTimeout(() => {
                    cardElement.remove();
                    // Update the halls count
                    updateHallsCount('all venues');
                    showSuccessMessage('Hall deleted successfully!');
                }, 300);
            }
        });
    }
}

// Add CSS animation for update effect
const style = document.createElement('style');
style.textContent = `
    @keyframes updateGlow {
        0% {
            box-shadow: 0 0 0 rgba(74, 144, 226, 0);
        }
        50% {
            box-shadow: 0 0 20px rgba(74, 144, 226, 0.3);
        }
        100% {
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }
    }
`;
document.head.appendChild(style);

// Image URL preview handler
document.getElementById('imageUrl').addEventListener('input', function(e) {
    const imagePreview = document.querySelector('.image-preview');
    if (imagePreview) {
        if (this.value) {
            imagePreview.style.display = 'block';
            imagePreview.style.backgroundImage = `url(${this.value})`;
        } else {
            imagePreview.style.display = 'none';
            imagePreview.style.backgroundImage = '';
        }
    }
});

// Booking filter functionality
function initializeBookingFilters() {
    const statusFilter = document.querySelector('select[class="filter-select"]');
    const categoryFilter = document.querySelectorAll('select[class="filter-select"]')[1];
    const searchInput = document.querySelector('.search-input input');
    const bookingTabs = document.querySelectorAll('.booking-tab');

    if (statusFilter) {
        statusFilter.addEventListener('change', filterBookings);
    }
    if (categoryFilter) {
        categoryFilter.addEventListener('change', filterBookings);
    }
    if (searchInput) {
        searchInput.addEventListener('input', filterBookings);
    }
    if (bookingTabs) {
        bookingTabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                bookingTabs.forEach(t => t.classList.remove('active'));
                e.target.classList.add('active');
                filterBookings();
            });
        });
    }
}

function filterBookings() {
    const statusFilter = document.querySelector('select[class="filter-select"]').value;
    const categoryFilter = document.querySelectorAll('select[class="filter-select"]')[1].value;
    const searchQuery = document.querySelector('.search-input input').value.toLowerCase();
    const activeTab = document.querySelector('.booking-tab.active').textContent.toLowerCase();

    const filteredBookings = bookings.filter(booking => {
        const matchesStatus = statusFilter === 'all' || booking.status.toLowerCase() === statusFilter;
        const matchesCategory = categoryFilter === 'all' || booking.category.toLowerCase() === categoryFilter;
        const matchesSearch = booking.hallName.toLowerCase().includes(searchQuery) ||
                            booking.userName.toLowerCase().includes(searchQuery) ||
                            booking.id.toLowerCase().includes(searchQuery);
        const matchesTab = activeTab === 'all bookings' ||
                          (activeTab === 'upcoming' && new Date(booking.date) >= new Date()) ||
                          (activeTab === 'past' && new Date(booking.date) < new Date());

        return matchesStatus && matchesCategory && matchesSearch && matchesTab;
    });

    const bookingTableBody = document.querySelector('.bookings-table tbody');
    bookingTableBody.innerHTML = '';
    
    if (filteredBookings.length === 0) {
        const emptyRow = document.createElement('tr');
        emptyRow.innerHTML = `
            <td colspan="8" style="text-align: center; padding: 40px;">
                <div style="color: #6B7280;">
                    <i class="fas fa-search" style="font-size: 24px; margin-bottom: 8px;"></i>
                    <p>No results found</p>
                    <p style="font-size: 12px;">Try adjusting your search or filter criteria</p>
                </div>
            </td>
        `;
        bookingTableBody.appendChild(emptyRow);
        return;
    }

    filteredBookings.forEach(booking => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${booking.id}</td>
            <td>${booking.hallName}</td>
            <td>${booking.category}</td>
            <td>${booking.userName}</td>
            <td>${booking.date} ${booking.startTime} - ${booking.endTime}</td>
            <td>
                <span class="status-badge ${booking.status.toLowerCase()}">
                    <i class="fas fa-circle"></i>
                    ${booking.status}
                </span>
            </td>
            <td>₹${booking.amount}</td>
            <td>
                <div class="table-actions">
                    <button class="action-btn view" onclick="viewBooking('${booking.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    ${booking.status === 'Pending' ? `
                        <button class="action-btn approve" onclick="approveBooking('${booking.id}')">
                            <i class="fas fa-check"></i>
                        </button>
                        <button class="action-btn reject" onclick="rejectBooking('${booking.id}')">
                            <i class="fas fa-times"></i>
                        </button>
                    ` : ''}
                    <button class="action-btn delete" onclick="deleteBooking('${booking.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        bookingTableBody.appendChild(row);
    });
}

// Booking action handlers
function viewBooking(id) {
    // Implement view booking functionality
    console.log('View booking:', id);
}

function editBooking(id) {
    // Implement edit booking functionality
    console.log('Edit booking:', id);
}

function deleteBooking(id) {
    // Implement delete booking functionality
    if (confirm('Are you sure you want to delete this booking?')) {
        bookings = bookings.filter(booking => booking.id !== id);
        renderBookings();
    }
}

// Function to render users table
function renderUsers() {
    const userTableBody = document.querySelector('.users-table tbody');
    if (!userTableBody) return;

    userTableBody.innerHTML = '';

    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="user-info">
                    <div class="user-avatar">${user.avatar}</div>
                    <div class="user-details">
                        <div class="user-name">${user.name}</div>
                        <div class="user-username">${user.username}</div>
                    </div>
                </div>
            </td>
            <td>${user.email}</td>
            <td>
                <span class="role-badge ${user.role.toLowerCase()}">${user.role}</span>
            </td>
            <td>
                <span class="status-badge ${user.status.toLowerCase()}">
                    <i class="fas fa-circle"></i>
                    ${user.status}
                </span>
            </td>
            <td class="joined-date">${user.joinedDate}</td>
            <td>
                <div class="user-actions">
                    <button class="user-action-btn more">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                </div>
            </td>
        `;
        userTableBody.appendChild(row);
    });
}

// Function to initialize user management
function initializeUserManagement() {
    const userTabs = document.querySelectorAll('.user-tab');
    const userSearch = document.querySelector('.user-search input');

    // Handle tab clicks
    userTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            userTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            filterUsers();
        });
    });

    // Handle search
    if (userSearch) {
        userSearch.addEventListener('input', filterUsers);
    }
}

// Function to filter users
function filterUsers() {
    const searchQuery = document.querySelector('.user-search input').value.toLowerCase();
    const activeTab = document.querySelector('.user-tab.active').textContent.toLowerCase();

    const filteredUsers = users.filter(user => {
        const matchesSearch = 
            user.name.toLowerCase().includes(searchQuery) ||
            user.username.toLowerCase().includes(searchQuery) ||
            user.email.toLowerCase().includes(searchQuery);
        
        const matchesTab = 
            activeTab === 'all users' ||
            (activeTab === 'active' && user.status.toLowerCase() === 'active') ||
            (activeTab === 'inactive' && user.status.toLowerCase() === 'inactive');

        return matchesSearch && matchesTab;
    });

    const userTableBody = document.querySelector('.users-table tbody');
    userTableBody.innerHTML = '';

    if (filteredUsers.length === 0) {
        const emptyRow = document.createElement('tr');
        emptyRow.innerHTML = `
            <td colspan="6" style="text-align: center; padding: 40px;">
                <div style="color: #6B7280;">
                    <i class="fas fa-search" style="font-size: 24px; margin-bottom: 8px;"></i>
                    <p>No users found</p>
                    <p style="font-size: 12px;">Try adjusting your search or filter criteria</p>
                </div>
            </td>
        `;
        userTableBody.appendChild(emptyRow);
        return;
    }

    filteredUsers.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>
                <div class="user-info">
                    <div class="user-avatar">${user.avatar}</div>
                    <div class="user-details">
                        <div class="user-name">${user.name}</div>
                        <div class="user-username">${user.username}</div>
                    </div>
                </div>
            </td>
            <td>${user.email}</td>
            <td>
                <span class="role-badge ${user.role.toLowerCase()}">${user.role}</span>
            </td>
            <td>
                <span class="status-badge ${user.status.toLowerCase()}">
                    <i class="fas fa-circle"></i>
                    ${user.status}
                </span>
            </td>
            <td class="joined-date">${user.joinedDate}</td>
            <td>
                <div class="user-actions">
                    <button class="user-action-btn more">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                </div>
            </td>
        `;
        userTableBody.appendChild(row);
    });
}

// Payment Management Functions
const transactions = [
    {
        id: 'TRX001',
        customer: 'John Doe',
        hallName: 'Grand Ballroom',
        date: '2024-03-15',
        amount: 15000,
        status: 'completed'
    },
    {
        id: 'TRX002',
        customer: 'Jane Smith',
        hallName: 'Crystal Hall',
        date: '2024-03-16',
        amount: 12000,
        status: 'pending'
    },
    {
        id: 'TRX003',
        customer: 'Mike Johnson',
        hallName: 'Garden View',
        date: '2024-03-14',
        amount: 18000,
        status: 'completed'
    }
];

function formatCurrency(amount) {
    return '₹' + amount.toLocaleString('en-IN');
}

function updateTransactionsList(filteredTransactions = transactions) {
    const transactionsList = document.getElementById('transactions-list');
    if (!transactionsList) return;

    transactionsList.innerHTML = '';
    
    filteredTransactions.forEach(transaction => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${transaction.id}</td>
            <td>${transaction.customer}</td>
            <td>${transaction.hallName}</td>
            <td>${transaction.date}</td>
            <td>${formatCurrency(transaction.amount)}</td>
            <td>
                <span class="payment-status ${transaction.status}">
                    <i class="fas fa-circle"></i>
                    ${transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                </span>
            </td>
            <td>
                <div class="payment-actions">
                    <button class="payment-action-btn view" title="View Details" onclick="viewTransactionDetails('${transaction.id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="payment-action-btn download" title="Download Invoice" onclick="downloadInvoice('${transaction.id}')">
                        <i class="fas fa-download"></i>
                    </button>
                </div>
            </td>
        `;
        transactionsList.appendChild(row);
    });
}

function filterTransactions(status) {
    const table = document.getElementById('transactions-list');
    if (!table) return; // Exit if table not found
    
    const rows = table.getElementsByTagName('tr');
    const searchQuery = document.getElementById('transaction-search')?.value.toLowerCase() || '';
    let visibleCount = 0;

    // First, hide all rows except header
    for (let row of rows) {
        if (row.cells.length > 0) { // Skip header row
            row.style.display = 'none';
        }
    }

    // Then show only matching rows
    for (let row of rows) {
        if (row.cells.length === 0) continue; // Skip header row
        
        const statusCell = row.querySelector('.payment-status');
        const customerCell = row.querySelector('td:nth-child(2)');
        const hallCell = row.querySelector('td:nth-child(3)');
        const dateCell = row.querySelector('td:nth-child(4)');
        const amountCell = row.querySelector('td:nth-child(5)');

        if (!statusCell || !customerCell || !hallCell || !dateCell || !amountCell) continue;

        let shouldShow = true;

        // Status filter
        if (status !== 'all') {
            const rowStatus = statusCell.textContent.trim().toLowerCase();
            if (rowStatus !== status) {
                shouldShow = false;
            }
        }

        // Search filter
        if (searchQuery) {
            const searchableText = [
                customerCell.textContent,
                hallCell.textContent,
                dateCell.textContent,
                amountCell.textContent
            ].join(' ').toLowerCase();

            if (!searchableText.includes(searchQuery)) {
                shouldShow = false;
            }
        }

        // Show/hide row based on filters
        if (shouldShow) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    }

    // Show "No results" message if no rows are visible
    const existingNoResults = table.querySelector('.no-results');
    if (existingNoResults) {
        existingNoResults.remove();
    }

    if (visibleCount === 0) {
        const noResultsRow = document.createElement('tr');
        noResultsRow.classList.add('no-results');
        noResultsRow.innerHTML = `
            <td colspan="7" style="text-align: center; padding: 20px;">
                No transactions found matching the selected filters.
            </td>
        `;
        table.appendChild(noResultsRow);
    }

    // Update payment stats based on visible rows
    updatePaymentStats();
}

function searchTransactions(query) {
    const filteredTransactions = transactions.filter(transaction => 
        transaction.id.toLowerCase().includes(query) ||
        transaction.customer.toLowerCase().includes(query) ||
        transaction.hallName.toLowerCase().includes(query)
    );
    updateTransactionsList(filteredTransactions);
}

function viewTransactionDetails(transactionId) {
    const transaction = transactions.find(t => t.id === transactionId);
    if (!transaction) return;
    
    // Show transaction details in a modal or separate view
    alert(`Viewing details for transaction ${transactionId}`);
}

function downloadInvoice(transactionId) {
    const transaction = transactions.find(t => t.id === transactionId);
    if (!transaction) return;
    
    // Generate and download invoice
    alert(`Downloading invoice for transaction ${transactionId}`);
}

// Event Listeners for Payment Management
document.addEventListener('DOMContentLoaded', () => {
    // Initialize navigation click handlers for payments
    const paymentLink = document.querySelector('a[href="#payments"]');
    if (paymentLink) {
        paymentLink.addEventListener('click', () => {
            // Initialize transactions list only when payment section is clicked
            updateTransactionsList();

            // Initialize payment filter
            const paymentFilter = document.getElementById('payment-filter');
            if (paymentFilter) {
                paymentFilter.addEventListener('change', (e) => {
                    filterTransactions(e.target.value);
                });
            }

            // Initialize transaction search
            const searchInput = document.getElementById('transaction-search');
            if (searchInput) {
                searchInput.addEventListener('input', (e) => {
                    searchTransactions(e.target.value.toLowerCase());
                });
            }
        });
    }
});

// Reports & Analytics Charts
function initializeReportsCharts() {
    Chart.defaults.responsive = true;
    Chart.defaults.maintainAspectRatio = false;

    // Weekly Bookings Chart
    const weeklyBookingsCtx = document.getElementById('weeklyBookingsChart').getContext('2d');
    new Chart(weeklyBookingsCtx, {
        type: 'bar',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Bookings',
                data: [5, 8, 12, 7, 15, 20, 10],
                backgroundColor: '#4A90E2',
                borderRadius: 5,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 20,
                    right: 20,
                    bottom: 20,
                    left: 20
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Monthly Revenue Chart
    const monthlyRevenueCtx = document.getElementById('monthlyRevenueChart').getContext('2d');
    new Chart(monthlyRevenueCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Revenue',
                data: [3500, 4200, 3800, 5000, 6200, 5800],
                borderColor: '#2ECC71',
                tension: 0.4,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 20,
                    right: 20,
                    bottom: 20,
                    left: 20
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Revenue Trends Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Revenue',
                data: [35000, 42000, 38000, 50000, 62000, 58000],
                borderColor: '#6366F1',
                tension: 0.4,
                fill: true,
                backgroundColor: 'rgba(99, 102, 241, 0.1)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 20,
                    right: 20,
                    bottom: 20,
                    left: 20
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    },
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString();
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Booking Distribution Chart
    const bookingCtx = document.getElementById('bookingDistributionChart').getContext('2d');
    const bookingChart = new Chart(bookingCtx, {
        type: 'doughnut',
        data: {
            labels: ['Wedding Halls', 'Conference Rooms', 'Meeting Rooms', 'Birthday Halls'],
            datasets: [{
                data: [35, 25, 20, 20],
                backgroundColor: ['#6366F1', '#10B981', '#F59E0B', '#EF4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: 20
            },
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            size: 12
                        }
                    }
                }
            },
            cutout: '60%'
        }
    });

    // Hall Utilization Chart
    const utilizationCtx = document.getElementById('utilizationChart').getContext('2d');
    const utilizationChart = new Chart(utilizationCtx, {
        type: 'bar',
        data: {
            labels: ['Grand Hall', 'Conference A', 'Meeting Room 1', 'Birthday Hall'],
            datasets: [{
                label: 'Utilization Rate',
                data: [85, 65, 75, 55],
                backgroundColor: '#6366F1',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 20,
                    right: 20,
                    bottom: 20,
                    left: 20
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        display: false
                    },
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Popular Time Slots Chart
    const timeSlotCtx = document.getElementById('timeSlotChart').getContext('2d');
    const timeSlotChart = new Chart(timeSlotCtx, {
        type: 'bar',
        data: {
            labels: ['9-11 AM', '11-1 PM', '1-3 PM', '3-5 PM', '5-7 PM', '7-9 PM'],
            datasets: [{
                label: 'Bookings',
                data: [15, 25, 20, 30, 35, 28],
                backgroundColor: '#6366F1',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 20,
                    right: 20,
                    bottom: 20,
                    left: 20
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });

    // Initialize mini charts for booking trends
    const miniCharts = document.querySelectorAll('.mini-chart');
    miniCharts.forEach((canvas, index) => {
        const ctx = canvas.getContext('2d');
        const data = generateTrendData(index);
        createMiniChart(ctx, data);
    });

    // Store chart instances globally for potential updates
    window.dashboardCharts = {
        revenueChart,
        bookingChart,
        utilizationChart,
        timeSlotChart
    };

    // Add resize handler
    window.addEventListener('resize', function() {
        if (window.dashboardCharts) {
            window.dashboardCharts.revenueChart.resize();
            window.dashboardCharts.bookingChart.resize();
            window.dashboardCharts.utilizationChart.resize();
            window.dashboardCharts.timeSlotChart.resize();
        }
    });
}

function initializeTrendCharts() {
    const miniCharts = document.querySelectorAll('.mini-chart');
    miniCharts.forEach((canvas, index) => {
        const ctx = canvas.getContext('2d');
        const data = generateTrendData(index);
        createMiniChart(ctx, data);
    });
}

function generateTrendData(index) {
    // Generate sample data for different trends
    const dataSets = [
        [65, 59, 80, 81, 56, 55, 40], // Wedding Halls
        [28, 48, 40, 19, 86, 27, 90], // Conference Rooms
        [45, 25, 16, 36, 67, 18, 76]  // Meeting Rooms
    ];
    return dataSets[index] || dataSets[0];
}

function createMiniChart(ctx, data) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                data: data,
                borderColor: '#4F46E5',
                borderWidth: 2,
                tension: 0.4,
                fill: false,
                pointRadius: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    display: false
                },
                y: {
                    display: false
                }
            }
        }
    });
}

function toggleChartType(button, chart) {
    const currentType = chart.config.type;
    const newType = currentType === 'line' ? 'bar' : 'line';
    
    // Update chart type
    chart.config.type = newType;
    
    // Update button icon
    const icon = button.querySelector('i');
    icon.className = newType === 'line' ? 'fas fa-chart-line' : 'fas fa-chart-bar';
    
    // Redraw chart
    chart.update();
}

// Add event listeners for chart type toggles
document.addEventListener('DOMContentLoaded', () => {
    // Initialize all charts when the page loads
    initializeReportsCharts();
    initializeTrendCharts();
    
    // Add event listeners for chart type toggles
    document.querySelectorAll('.chart-type-toggle').forEach(button => {
        button.addEventListener('click', (e) => {
            const container = e.target.closest('.trend-chart-container');
            const canvas = container.querySelector('canvas');
            const chart = Chart.getChart(canvas);
            if (chart) {
                toggleChartType(button, chart);
            }
        });
    });
});

// Initialize reports when the section becomes active
document.addEventListener('DOMContentLoaded', () => {
    const reportsLink = document.querySelector('a[href="#reports"]');
    if (reportsLink) {
        reportsLink.addEventListener('click', () => {
            // Small delay to ensure the canvas elements are visible
            setTimeout(() => {
                initializeReportsCharts();
                initializeTrendCharts();
                // Force resize after initialization
                window.dispatchEvent(new Event('resize'));
            }, 100);
        });
    }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    renderHalls();
    renderBookings();
    initializeBookingFilters();
    renderUsers();
    initializeUserManagement();
    initializeProfilePicture();
});

async function downloadAnalysisReport() {
    try {
        // Show loading indicator
        const downloadBtn = document.querySelector('.download-report-btn');
        downloadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating Report...';
        downloadBtn.disabled = true;

        // Get the reports section
        const reportsSection = document.getElementById('reports');
        
        // Create a temporary container for the report
        const tempContainer = document.createElement('div');
        tempContainer.innerHTML = reportsSection.innerHTML;
        
        // Remove interactive elements and buttons
        const elementsToRemove = tempContainer.querySelectorAll('.chart-type-toggle, .date-range-btn, .download-report-btn, .stats-period-select');
        elementsToRemove.forEach(el => el.remove());

        // Convert all charts to high-quality images
        const charts = Chart.instances;
        const chartImages = {};
        
        // First, capture all regular charts with higher resolution
        for (const chartId in charts) {
            const chart = charts[chartId];
            const canvas = chart.canvas;
            
            // Create a temporary high-resolution canvas
            const tempCanvas = document.createElement('canvas');
            const ctx = tempCanvas.getContext('2d');
            const scale = 2; // Increase resolution
            
            tempCanvas.width = canvas.width * scale;
            tempCanvas.height = canvas.height * scale;
            
            // Scale the context for higher resolution
            ctx.scale(scale, scale);
            
            // Draw the chart with white background
            ctx.fillStyle = 'white';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            // Draw the chart
            chart.draw();
            ctx.drawImage(canvas, 0, 0, canvas.width, canvas.height);
            
            const imageData = tempCanvas.toDataURL('image/png', 1.0);
            chartImages[canvas.id] = imageData;
        }

        // Then, capture all mini charts in the booking trends table
        const miniCharts = document.querySelectorAll('.mini-chart');
        miniCharts.forEach((canvas, index) => {
            const chart = Chart.getChart(canvas);
            if (chart) {
                const imageData = canvas.toDataURL('image/png', 1.0);
                chartImages[canvas.id] = imageData;
            }
        });

        // Create a new window for printing
        const printWindow = window.open('', '_blank');
        
        // Add professional styles to the new window
        printWindow.document.write(`
            <html>
                <head>
                    <title>Hall Management System - Analysis Report</title>
                    <style>
                        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
                        
                        * {
                            margin: 0;
                            padding: 0;
                            box-sizing: border-box;
                        }
                        
                        body {
                            font-family: 'Inter', sans-serif;
                            line-height: 1.6;
                            color: #1F2937;
                            padding: 40px;
                            background: #F9FAFB;
                        }
                        
                        .report-header {
                            text-align: center;
                            margin-bottom: 40px;
                            padding-bottom: 20px;
                            border-bottom: 2px solid #E5E7EB;
                        }
                        
                        .report-header h1 {
                            font-size: 28px;
                            font-weight: 700;
                            color: #111827;
                            margin-bottom: 10px;
                        }
                        
                        .report-header p {
                            color: #6B7280;
                            font-size: 14px;
                        }
                        
                        .report-meta {
                            display: flex;
                            justify-content: space-between;
                            margin-bottom: 30px;
                            font-size: 14px;
                            color: #6B7280;
                        }
                        
                        .analytics-overview {
                            display: grid;
                            grid-template-columns: repeat(4, 1fr);
                            gap: 20px;
                            margin-bottom: 40px;
                        }
                        
                        .analytics-card {
                            background: #FFFFFF;
                            padding: 24px;
                            border-radius: 12px;
                            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                            border: 1px solid #E5E7EB;
                        }
                        
                        .chart-container {
                            background: #FFFFFF;
                            padding: 20px;
                            border-radius: 12px;
                            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
                            margin: 20px 0;
                            page-break-inside: avoid;
                        }
                        
                        .chart-container img {
                            width: 100%;
                            height: auto;
                            display: block;
                            margin: 0 auto;
                        }
                        
                        .report-section {
                            margin-bottom: 40px;
                            page-break-inside: avoid;
                        }
                        
                        .report-section h2 {
                            font-size: 20px;
                            font-weight: 600;
                            color: #111827;
                            margin-bottom: 16px;
                        }
                        
                        @media print {
                            body {
                                padding: 20px;
                            }
                            
                            .chart-container {
                                break-inside: avoid;
                                page-break-inside: avoid;
                            }
                            
                            .analytics-overview {
                                break-inside: avoid;
                                page-break-inside: avoid;
                            }
                        }
                    </style>
                </head>
                <body>
                    <div class="report-header">
                        <h1>Hall Management System Analysis Report</h1>
                        <p>Comprehensive analysis of hall bookings, revenue, and utilization</p>
                    </div>
                    
                    <div class="report-meta">
                        <div>Generated on: ${new Date().toLocaleString()}</div>
                        <div>Report Period: Last 30 Days</div>
                    </div>
                    
                    ${tempContainer.innerHTML}
                    
                    <div class="report-footer" style="margin-top: 40px; padding-top: 20px; border-top: 2px solid #E5E7EB; text-align: center; color: #6B7280; font-size: 12px;">
                        <p>This report was generated by the Hall Management System</p>
                        <p>© ${new Date().getFullYear()} Hall Management System. All rights reserved.</p>
                    </div>
                </body>
            </html>
        `);

        // Replace canvas elements with high-quality images
        const chartContainers = printWindow.document.querySelectorAll('.chart-container, .trend-chart-container');
        chartContainers.forEach(container => {
            const canvas = container.querySelector('canvas');
            if (canvas && chartImages[canvas.id]) {
                const img = document.createElement('img');
                img.src = chartImages[canvas.id];
                img.alt = 'Chart';
                container.innerHTML = '';
                container.appendChild(img);
            }
        });

        // Wait for images to load before printing
        const images = printWindow.document.querySelectorAll('img');
        await Promise.all(Array.from(images).map(img => {
            return new Promise((resolve, reject) => {
                img.onload = resolve;
                img.onerror = reject;
            });
        }));

        // Close the document and print
        printWindow.document.close();
        printWindow.onload = function() {
            setTimeout(() => {
                printWindow.print();
                downloadBtn.innerHTML = '<i class="fas fa-download"></i> Download Report';
                downloadBtn.disabled = false;
            }, 1000);
        };
    } catch (error) {
        console.error('Error generating report:', error);
        const downloadBtn = document.querySelector('.download-report-btn');
        downloadBtn.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error';
        downloadBtn.disabled = false;
        
        // Show error message to user
        showSuccessMessage('Error generating report. Please try again.');
        
        setTimeout(() => {
            downloadBtn.innerHTML = '<i class="fas fa-download"></i> Download Report';
        }, 3000);
    }
}

// Add event listener for the download button
document.addEventListener('DOMContentLoaded', () => {
    const downloadBtn = document.querySelector('.download-report-btn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', downloadAnalysisReport);
    }
});

// Notification Management Functions
function initializeNotificationSettings() {
    // Load saved notification settings
    const emailEnabled = localStorage.getItem('emailNotifications') === 'true';
    const smsEnabled = localStorage.getItem('smsNotifications') === 'true';
    
    document.getElementById('email-toggle').checked = emailEnabled;
    document.getElementById('sms-toggle').checked = smsEnabled;
    
    // Load saved templates
    const emailTemplate = localStorage.getItem('emailTemplate') || 
        `Dear {customer_name},

Your booking for {hall_name} has been confirmed for {booking_date}.

Booking Details:
- Hall: {hall_name}
- Date: {booking_date}
- Time: {booking_time}
- Duration: {duration} hours
- Total Amount: ₹{amount}

Thank you for choosing our services!

Best regards,
Hall Management Team`;

    const smsTemplate = localStorage.getItem('smsTemplate') || 
        `Dear {customer_name}, your booking for {hall_name} on {booking_date} at {booking_time} has been confirmed. Total amount: ₹{amount}. Thank you!`;

    document.getElementById('email-template').value = emailTemplate;
    document.getElementById('sms-template').value = smsTemplate;
}

function saveNotificationSettings() {
    const emailEnabled = document.getElementById('email-toggle').checked;
    const smsEnabled = document.getElementById('sms-toggle').checked;
    
    localStorage.setItem('emailNotifications', emailEnabled);
    localStorage.setItem('smsNotifications', smsEnabled);
    
    showSuccessMessage('Notification settings saved successfully');
}

function saveEmailTemplate() {
    const template = document.getElementById('email-template').value;
    localStorage.setItem('emailTemplate', template);
    showSuccessMessage('Email template saved successfully');
}

function saveSMSTemplate() {
    const template = document.getElementById('sms-template').value;
    localStorage.setItem('smsTemplate', template);
    showSuccessMessage('SMS template saved successfully');
}

function sendTestNotification(type) {
    const template = type === 'email' ? 
        document.getElementById('email-template').value :
        document.getElementById('sms-template').value;
    
    // Replace placeholders with test data
    const testData = {
        customer_name: 'Test User',
        hall_name: 'Grand Ballroom',
        booking_date: '2024-03-20',
        booking_time: '14:00',
        duration: '4',
        amount: '15000'
    };
    
    let message = template;
    for (const [key, value] of Object.entries(testData)) {
        message = message.replace(new RegExp(`{${key}}`, 'g'), value);
    }
    
    // Add to notification history
    const historyTable = document.querySelector('.notification-history table tbody');
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td>${new Date().toLocaleString()}</td>
        <td>${type.toUpperCase()}</td>
        <td>test@example.com</td>
        <td><span class="status-badge delivered">Delivered</span></td>
        <td>${message}</td>
    `;
    historyTable.insertBefore(newRow, historyTable.firstChild);
    
    showSuccessMessage(`Test ${type.toUpperCase()} notification sent successfully`);
}

// Notification Filtering Functions
function initializeNotificationFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const notificationItems = document.querySelectorAll('.notification-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');

            const filter = button.getAttribute('data-filter');
            filterNotifications(filter);
        });
    });
}

function filterNotifications(status) {
    const notificationItems = document.querySelectorAll('.notification-item');
    
    notificationItems.forEach(item => {
        if (status === 'all') {
            item.classList.remove('hidden');
        } else {
            if (item.getAttribute('data-status') === status) {
                item.classList.remove('hidden');
            } else {
                item.classList.add('hidden');
            }
        }
    });
}

// Initialize notification filters when the page loads
document.addEventListener('DOMContentLoaded', () => {
    initializeNotificationSettings();
    initializeNotificationFilters();
    
    // Add event listeners for notification settings
    document.getElementById('email-toggle').addEventListener('change', saveNotificationSettings);
    document.getElementById('sms-toggle').addEventListener('change', saveNotificationSettings);
    
    // Add event listeners for template editing
    document.getElementById('save-email-template').addEventListener('click', saveEmailTemplate);
    document.getElementById('save-sms-template').addEventListener('click', saveSMSTemplate);
    
    // Add event listeners for test notifications
    document.getElementById('send-test-notification').addEventListener('click', () => sendTestNotification('email'));
});

// Function to open the announcement modal
function openAnnouncementModal() {
    const modal = document.getElementById('addAnnouncementModal');
    modal.style.display = 'block';
    // Set min date to today for start and end date inputs
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('startDate').min = today;
    document.getElementById('endDate').min = today;
    
    // Reset form and clear any previous validation states
    document.getElementById('announcementForm').reset();
    clearValidationErrors();
}

// Function to close the announcement modal
function closeAnnouncementModal() {
    const modal = document.getElementById('addAnnouncementModal');
    modal.style.display = 'none';
    // Reset form and clear validation errors
    document.getElementById('announcementForm').reset();
    clearValidationErrors();
}

// Function to clear validation errors
function clearValidationErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(element => element.remove());
    const inputs = document.querySelectorAll('.error');
    inputs.forEach(input => input.classList.remove('error'));
}

// Function to validate announcement form
function validateAnnouncementForm() {
    let isValid = true;
    clearValidationErrors();
    
    const title = document.getElementById('announcementTitle').value.trim();
    const content = document.getElementById('announcementContent').value.trim();
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    if (!title) {
        showError('announcementTitle', 'Title is required');
        isValid = false;
    }
    
    if (!content) {
        showError('announcementContent', 'Content is required');
        isValid = false;
    }
    
    if (!startDate) {
        showError('startDate', 'Start date is required');
        isValid = false;
    }
    
    if (!endDate) {
        showError('endDate', 'End date is required');
        isValid = false;
    }
    
    if (startDate && endDate && new Date(startDate) > new Date(endDate)) {
        showError('endDate', 'End date must be after start date');
        isValid = false;
    }
    
    return isValid;
}

// Function to show error message
function showError(inputId, message) {
    const input = document.getElementById(inputId);
    input.classList.add('error');
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    input.parentNode.appendChild(errorDiv);
}

// Function to create announcement
function createAnnouncement(event) {
    event.preventDefault();
    
    if (!validateAnnouncementForm()) {
        return;
    }
    
    const title = document.getElementById('announcementTitle').value.trim();
    const content = document.getElementById('announcementContent').value.trim();
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const status = document.getElementById('announcementStatus').value;
    
    const newAnnouncement = {
        id: Date.now(),
        title,
        content,
        startDate,
        endDate,
        status,
        createdAt: new Date().toISOString(),
        createdBy: 'Admin User'
    };
    
    try {
        announcements.unshift(newAnnouncement);
        displayAnnouncements();
        closeAnnouncementModal();
        showSuccessMessage('Announcement created successfully!');
    } catch (error) {
        showError('announcementForm', 'Failed to create announcement. Please try again.');
        console.error('Error creating announcement:', error);
    }
}

// Function to display announcements
function displayAnnouncements() {
    const announcementsList = document.getElementById('announcements-list');
    if (!announcementsList) return;
    
    announcementsList.innerHTML = announcements.map(announcement => `
        <tr>
            <td>${announcement.title}</td>
            <td>${announcement.createdBy}</td>
            <td>${formatDate(announcement.startDate)}</td>
            <td>${formatDate(announcement.endDate)}</td>
            <td>
                <span class="status-badge ${announcement.status.toLowerCase()}">
                    <i class="fas fa-circle"></i>
                    ${announcement.status}
                </span>
            </td>
            <td>${formatDate(announcement.createdAt)}</td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn edit" onclick="editAnnouncement(${announcement.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" onclick="deleteAnnouncement(${announcement.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');

    // Update announcement stats
    updateAnnouncementStats();
}

// Function to update announcement stats
function updateAnnouncementStats() {
    const activeCount = announcements.filter(a => a.status === 'active').length;
    const inactiveCount = announcements.filter(a => a.status === 'inactive').length;
    const totalCount = announcements.length;

    // Update stats in the UI
    document.querySelector('.announcement-stats .stat-card:nth-child(1) .stat-number').textContent = activeCount;
    document.querySelector('.announcement-stats .stat-card:nth-child(2) .stat-number').textContent = totalCount;
    document.querySelector('.announcement-stats .stat-card:nth-child(3) .stat-number').textContent = inactiveCount;
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    const newAnnouncementBtn = document.querySelector('.new-announcement-btn');
    const announcementForm = document.getElementById('addAnnouncementForm');
    const closeModalBtn = document.getElementById('closeAnnouncementModal');
    
    if (newAnnouncementBtn) {
        newAnnouncementBtn.addEventListener('click', openAnnouncementModal);
    }
    
    if (announcementForm) {
        announcementForm.addEventListener('submit', createAnnouncement);
    }
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeAnnouncementModal);
    }
    
    // Initialize announcements display
    displayAnnouncements();
});

// Helper function to format date
function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Function to open feedback modal
function openFeedbackModal() {
    const modal = document.getElementById('addFeedbackModal');
    modal.style.display = 'block';
}

// Function to close feedback modal
function closeFeedbackModal() {
    const modal = document.getElementById('addFeedbackModal');
    modal.style.display = 'none';
    document.getElementById('addFeedbackForm').reset();
}

// Function to create feedback
function createFeedback(event) {
    event.preventDefault();
    
    const title = document.getElementById('feedbackTitle').value;
    const type = document.getElementById('feedbackType').value;
    const priority = document.getElementById('feedbackPriority').value;
    const description = document.getElementById('feedbackDescription').value;
    const assignedTo = document.getElementById('assignTo').value;
    
    const newFeedback = {
        id: `FB${String(feedbacks.length + 1).padStart(3, '0')}`,
        title,
        type,
        priority,
        description,
        assignedTo,
        status: 'pending',
        date: new Date().toISOString(),
        user: 'John Doe',
        assignedToName: document.getElementById('assignTo').options[document.getElementById('assignTo').selectedIndex].text
    };
    
    feedbacks.unshift(newFeedback);
    displayFeedbacks();
    closeFeedbackModal();
    updateFeedbackStats();
    showSuccessMessage('Feedback submitted successfully!');
}

// Function to display feedbacks
function displayFeedbacks() {
    const feedbackList = document.getElementById('feedback-list');
    if (!feedbackList) return;
    
    feedbackList.innerHTML = feedbacks.map(feedback => `
        <tr>
            <td>${feedback.id}</td>
            <td>
                <span class="feedback-type ${feedback.type.toLowerCase()}">
                    ${feedback.type.charAt(0).toUpperCase() + feedback.type.slice(1)}
                </span>
            </td>
            <td>${feedback.title}</td>
            <td>${feedback.user}</td>
            <td>
                <span class="feedback-status ${feedback.status.toLowerCase()}">
                    <i class="fas fa-circle"></i>
                    ${feedback.status.charAt(0).toUpperCase() + feedback.status.slice(1)}
                </span>
            </td>
            <td>${formatDate(feedback.date)}</td>
            <td>${feedback.assignedToName}</td>
            <td>
                <div class="feedback-actions">
                    <button class="feedback-action-btn view" onclick="viewFeedback('${feedback.id}')" title="View Details">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="feedback-action-btn edit" onclick="editFeedback('${feedback.id}')" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="feedback-action-btn delete" onclick="deleteFeedback('${feedback.id}')" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Function to update feedback stats
function updateFeedbackStats() {
    const totalCount = feedbacks.length;
    const pendingCount = feedbacks.filter(f => f.status === 'pending').length;
    const inProgressCount = feedbacks.filter(f => f.status === 'in-progress').length;
    const resolvedCount = feedbacks.filter(f => f.status === 'resolved').length;

    document.querySelector('.feedback-stats .stat-card:nth-child(1) .stat-number').textContent = totalCount;
    document.querySelector('.feedback-stats .stat-card:nth-child(2) .stat-number').textContent = pendingCount;
    document.querySelector('.feedback-stats .stat-card:nth-child(3) .stat-number').textContent = inProgressCount;
    document.querySelector('.feedback-stats .stat-card:nth-child(4) .stat-number').textContent = resolvedCount;
}

// Function to filter feedbacks
function filterFeedbacks(status) {
    const filteredFeedbacks = status === 'all' 
        ? feedbacks 
        : feedbacks.filter(f => f.status === status || f.type === status);
    
    displayFilteredFeedbacks(filteredFeedbacks);
}

// Function to display filtered feedbacks
function displayFilteredFeedbacks(filteredFeedbacks) {
    const feedbackList = document.getElementById('feedback-list');
    if (!feedbackList) return;
    
    if (filteredFeedbacks.length === 0) {
        feedbackList.innerHTML = `
            <tr>
                <td colspan="8" class="empty-state">
                    <div class="empty-state-content">
                        <i class="fas fa-search"></i>
                        <p>No results found</p>
                        <p class="empty-state-description">Try adjusting your search or filter criteria</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    feedbackList.innerHTML = filteredFeedbacks.map(feedback => `
        <tr>
            <td>${feedback.id}</td>
            <td>
                <span class="feedback-type ${feedback.type.toLowerCase()}">
                    ${feedback.type.charAt(0).toUpperCase() + feedback.type.slice(1)}
                </span>
            </td>
            <td>${feedback.title}</td>
            <td>${feedback.user}</td>
            <td>
                <span class="feedback-status ${feedback.status.toLowerCase()}">
                    <i class="fas fa-circle"></i>
                    ${feedback.status.charAt(0).toUpperCase() + feedback.status.slice(1)}
                </span>
            </td>
            <td>${formatDate(feedback.date)}</td>
            <td>${feedback.assignedToName}</td>
            <td>
                <div class="feedback-actions">
                    <button class="feedback-action-btn view" onclick="viewFeedback('${feedback.id}')" title="View Details">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="feedback-action-btn edit" onclick="editFeedback('${feedback.id}')" title="Edit">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="feedback-action-btn delete" onclick="deleteFeedback('${feedback.id}')" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Function to search feedbacks
function searchFeedbacks(query) {
    const filteredFeedbacks = feedbacks.filter(feedback => 
        feedback.title.toLowerCase().includes(query.toLowerCase()) ||
        feedback.id.toLowerCase().includes(query.toLowerCase()) ||
        feedback.user.toLowerCase().includes(query.toLowerCase())
    );
    
    displayFilteredFeedbacks(filteredFeedbacks);
}

// Function to view feedback details
function viewFeedback(id) {
    const feedback = feedbacks.find(f => f.id === id);
    if (!feedback) return;
    
    // Show feedback details in a modal
    alert(`Viewing feedback: ${feedback.title}`);
}

// Function to edit feedback
function editFeedback(id) {
    const feedback = feedbacks.find(f => f.id === id);
    if (!feedback) return;
    
    document.getElementById('feedbackTitle').value = feedback.title;
    document.getElementById('feedbackType').value = feedback.type;
    document.getElementById('feedbackPriority').value = feedback.priority;
    document.getElementById('feedbackDescription').value = feedback.description;
    document.getElementById('assignTo').value = feedback.assignedTo;
    
    openFeedbackModal();
    
    const form = document.getElementById('addFeedbackForm');
    form.onsubmit = (e) => {
        e.preventDefault();
        
        feedback.title = document.getElementById('feedbackTitle').value;
        feedback.type = document.getElementById('feedbackType').value;
        feedback.priority = document.getElementById('feedbackPriority').value;
        feedback.description = document.getElementById('feedbackDescription').value;
        feedback.assignedTo = document.getElementById('assignTo').value;
        feedback.assignedToName = document.getElementById('assignTo').options[document.getElementById('assignTo').selectedIndex].text;
        
        displayFeedbacks();
        closeFeedbackModal();
        showSuccessMessage('Feedback updated successfully!');
    };
}

// Function to delete feedback
function deleteFeedback(id) {
    if (confirm('Are you sure you want to delete this feedback?')) {
        const index = feedbacks.findIndex(f => f.id === id);
        if (index > -1) {
            feedbacks.splice(index, 1);
            displayFeedbacks();
            updateFeedbackStats();
            showSuccessMessage('Feedback deleted successfully!');
        }
    }
}

// Initialize feedback management
document.addEventListener('DOMContentLoaded', () => {
    const newFeedbackBtn = document.querySelector('.new-feedback-btn');
    const feedbackForm = document.getElementById('addFeedbackForm');
    const closeModalBtn = document.querySelector('#addFeedbackModal .close');
    const filterTabs = document.querySelectorAll('.filter-tab');
    const searchInput = document.querySelector('.feedback-filters .search-input input');
    
    if (newFeedbackBtn) {
        newFeedbackBtn.addEventListener('click', openFeedbackModal);
    }
    
    if (feedbackForm) {
        feedbackForm.addEventListener('submit', createFeedback);
    }
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeFeedbackModal);
    }
    
    // Filter tabs functionality
    filterTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            filterTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            filterFeedbacks(tab.getAttribute('data-filter'));
        });
    });
    
    // Search functionality
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            searchFeedbacks(e.target.value);
        });
    }
    
    // Initialize display
    displayFeedbacks();
    updateFeedbackStats();
});

// Settings Section Functionality
function initializeSettings() {
    const settingsTabs = document.querySelectorAll('.settings-tab');
    const settingsPanels = document.querySelectorAll('.settings-panel');

    // Handle tab switching with animation
    settingsTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetPanel = tab.getAttribute('data-tab');
            
            // Update active tab
            settingsTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Hide all panels with fade out animation
            settingsPanels.forEach(panel => {
                panel.style.animation = 'fadeOut 0.3s ease-out';
                setTimeout(() => {
                    panel.classList.remove('active');
                    panel.style.animation = '';
                }, 300);
            });
            
            // Show target panel with slide in animation
            setTimeout(() => {
                const activePanel = document.getElementById(`${targetPanel}-settings`);
                if (activePanel) {
                    activePanel.classList.add('active');
                    activePanel.style.animation = 'slideIn 0.3s ease-out';
                }
            }, 300);
        });
    });

    // Handle form submissions
    const profileForm = document.querySelector('#profile-settings form');
    const passwordForm = document.querySelector('#password-settings form');

    if (profileForm) {
        profileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Add loading state
            const submitBtn = profileForm.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            submitBtn.disabled = true;

            // Get form values
            const fullName = document.getElementById('fullName').value;
            const email = document.getElementById('email').value;
            const username = document.getElementById('username').value;

            // Update navbar profile
            const navbarProfileName = document.querySelector('.admin-profile span');
            const sidebarProfileName = document.querySelector('.admin-name');
            const welcomeMessage = document.querySelector('.welcome-message h2');
            const adminAvatar = document.querySelectorAll('.admin-avatar');

            // Update the profile information
            if (navbarProfileName) navbarProfileName.textContent = fullName;
            if (sidebarProfileName) sidebarProfileName.textContent = fullName;
            if (welcomeMessage) welcomeMessage.textContent = `Welcome back, ${fullName}!`;
            
            // Update avatar initials
            const initials = fullName.split(' ').map(n => n[0]).join('').toUpperCase();
            adminAvatar.forEach(avatar => {
                avatar.textContent = initials;
            });

            // Simulate API call
            setTimeout(() => {
                submitBtn.innerHTML = 'Save Changes';
                submitBtn.disabled = false;
                showSuccessMessage('Profile updated successfully!');
            }, 1500);
        });
    }

    if (passwordForm) {
        passwordForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Add loading state
            const submitBtn = passwordForm.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
            submitBtn.disabled = true;

            // Simulate API call
            setTimeout(() => {
                submitBtn.innerHTML = 'Update Password';
                submitBtn.disabled = false;
                showSuccessMessage('Password updated successfully');
                passwordForm.reset();
            }, 1500);
        });
    }

    // Handle input animations
    const formInputs = document.querySelectorAll('.settings-form input, .settings-form select');
    formInputs.forEach(input => {
        input.addEventListener('focus', () => {
            input.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', () => {
            input.parentElement.classList.remove('focused');
        });
    });
}

// Initialize settings when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializeSettings();
});

// Profile Picture Management
function initializeProfilePicture() {
    const profilePictureWrapper = document.querySelector('.profile-picture-wrapper');
    const profilePicture = document.getElementById('profilePicture');
    const profilePictureInput = document.getElementById('profilePictureInput');
    const changeProfilePictureBtn = document.getElementById('changeProfilePicture');
    const removeProfilePictureBtn = document.getElementById('removeProfilePicture');

    // Handle click on profile picture or upload button
    [profilePictureWrapper, changeProfilePictureBtn].forEach(element => {
        element.addEventListener('click', () => {
            profilePictureInput.click();
        });
    });

    // Handle file selection
    profilePictureInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
            if (validateImage(file)) {
                await uploadProfilePicture(file);
            }
        }
    });

    // Handle remove picture
    removeProfilePictureBtn.addEventListener('click', removeProfilePicture);
}

function validateImage(file) {
    // Check file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!validTypes.includes(file.type)) {
        showSuccessMessage('Please select a valid image file (JPEG, PNG, or GIF)');
        return false;
    }

    // Check file size (max 5MB)
    const maxSize = 5 * 1024 * 1024; // 5MB in bytes
    if (file.size > maxSize) {
        showSuccessMessage('Image size should be less than 5MB');
        return false;
    }

    return true;
}

async function uploadProfilePicture(file) {
    const profilePicture = document.getElementById('profilePicture');
    const wrapper = document.querySelector('.profile-picture-wrapper');
    
    try {
        // Add loading state
        wrapper.classList.add('uploading');
        
        // Create a preview
        const reader = new FileReader();
        reader.onload = function(e) {
            profilePicture.src = e.target.result;
        }
        reader.readAsDataURL(file);

        // Simulate upload delay (replace with actual upload logic)
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Show success state
        wrapper.classList.remove('uploading');
        wrapper.classList.add('upload-success');
        showSuccessMessage('Profile picture updated successfully');
        
        // Remove success state after animation
        setTimeout(() => {
            wrapper.classList.remove('upload-success');
        }, 1500);
        
    } catch (error) {
        console.error('Error uploading profile picture:', error);
        showSuccessMessage('Failed to upload profile picture');
        wrapper.classList.remove('uploading');
    }
}

function removeProfilePicture() {
    const profilePicture = document.getElementById('profilePicture');
    const defaultImage = 'https://via.placeholder.com/150';
    
    profilePicture.src = defaultImage;
    showSuccessMessage('Profile picture removed');
}

// Add to your existing initialization code
document.addEventListener('DOMContentLoaded', function() {
    // ... existing initialization code ...
    initializeProfilePicture();
});

// ... existing code ... 

// Initialize profile settings
function initializeProfileSettings() {
    const profileForm = document.querySelector('#profile-settings form');
    const changeProfilePictureBtn = document.getElementById('changeProfilePicture');
    const removeProfilePictureBtn = document.getElementById('removeProfilePicture');
    const profilePictureInput = document.getElementById('profilePictureInput');
    const profilePicture = document.getElementById('profilePicture');

    if (profileForm) {
        profileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get form values
            const fullName = document.getElementById('fullName').value;
            const email = document.getElementById('email').value;
            const username = document.getElementById('username').value;
            const timezone = document.getElementById('timezone').value;

            // Update navbar and sidebar profile
            const navbarProfileName = document.querySelector('.admin-profile span');
            const sidebarProfileName = document.querySelector('.admin-name');
            const welcomeMessage = document.querySelector('.welcome-message h2');
            const adminAvatar = document.querySelectorAll('.admin-avatar');

            // Update profile information
            if (navbarProfileName) navbarProfileName.textContent = fullName;
            if (sidebarProfileName) sidebarProfileName.textContent = fullName;
            if (welcomeMessage) welcomeMessage.textContent = `Welcome back, ${fullName}!`;
            
            // Update avatar initials
            const initials = fullName.split(' ').map(n => n[0]).join('').toUpperCase();
            adminAvatar.forEach(avatar => {
                avatar.textContent = initials;
            });

            // Show success message
            showSuccessMessage('Profile updated successfully!');
        });
    }

    // Handle profile picture change
    if (changeProfilePictureBtn) {
        changeProfilePictureBtn.addEventListener('click', () => {
            profilePictureInput.click();
        });
    }

    if (profilePictureInput) {
        profilePictureInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                if (validateImage(file)) {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        profilePicture.src = e.target.result;
                        // Update avatar in navbar and sidebar
                        const avatars = document.querySelectorAll('.admin-avatar');
                        avatars.forEach(avatar => {
                            avatar.innerHTML = `<img src="${e.target.result}" alt="Profile Picture">`;
                        });
                    };
                    reader.readAsDataURL(file);
                }
            }
        });
    }

    // Handle profile picture removal
    if (removeProfilePictureBtn) {
        removeProfilePictureBtn.addEventListener('click', () => {
            profilePicture.src = 'https://via.placeholder.com/150';
            // Reset avatar to initials
            const fullName = document.getElementById('fullName').value;
            const initials = fullName.split(' ').map(n => n[0]).join('').toUpperCase();
            const avatars = document.querySelectorAll('.admin-avatar');
            avatars.forEach(avatar => {
                avatar.textContent = initials;
            });
        });
    }
}

// Initialize settings when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializeProfileSettings();
});
// ... existing code ... 

// Handle profile settings navigation
document.addEventListener('DOMContentLoaded', function() {
    const profileLink = document.querySelector('.dropdown-item[data-tab="profile"]');
    if (profileLink) {
        profileLink.addEventListener('click', function(e) {
            e.preventDefault();
            // Hide all sections
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });
            // Show settings section
            document.getElementById('settings').classList.add('active');
            // Activate profile tab
            document.querySelector('.settings-tab[data-tab="profile"]').click();
        });
    }
});

// Logout function
function logout() {
    // Clear session storage
    sessionStorage.removeItem('isLoggedIn');
    // Redirect to login page
    window.location.href = 'login.html';
}

// ... existing code ... 

// Initialize Charts
function initializeCharts() {
    // Weekly Bookings Chart
    const weeklyBookingsCtx = document.getElementById('weeklyBookingsChart').getContext('2d');
    new Chart(weeklyBookingsCtx, {
        type: 'bar',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Bookings',
                data: [5, 8, 12, 7, 15, 20, 10],
                backgroundColor: '#4A90E2',
                borderRadius: 5,
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Monthly Revenue Chart
    const monthlyRevenueCtx = document.getElementById('monthlyRevenueChart').getContext('2d');
    new Chart(monthlyRevenueCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Revenue',
                data: [3500, 4200, 3800, 5000, 6200, 5800],
                borderColor: '#2ECC71',
                tension: 0.4,
                fill: false
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        display: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// Function to filter halls by category
function filterHalls(category) {
    // Remove active class from all tabs
    document.querySelectorAll('.category-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Add active class to clicked tab
    event.target.classList.add('active');
    
    // Get all hall cards
    const halls = document.querySelectorAll('.hall-card');
    
    // Filter halls
    halls.forEach(hall => {
        const hallType = hall.getAttribute('data-hall-type');
        if (category === 'All Venues' || hallType === category) {
            hall.style.display = 'flex';
        } else {
            hall.style.display = 'none';
        }
    });
}

// Function to edit a hall
function editHall(button) {
    const card = button.closest('.hall-card');
    const hallName = card.querySelector('.hall-name').textContent;
    const hallType = card.querySelector('.hall-type').textContent;
    const hallPrice = card.querySelector('.hall-price').textContent;
    const hallLocation = card.querySelector('.hall-location span').textContent;
    const hallCapacity = card.querySelector('.hall-capacity span').textContent;
    
    // Open edit modal with current values
    const modal = document.getElementById('addHallModal');
    modal.style.display = 'block';
    
    // Fill form with current values
    document.getElementById('hallName').value = hallName;
    document.getElementById('hallType').value = hallType;
    document.getElementById('price').value = hallPrice.replace('₹', '').replace('/hr', '');
    document.getElementById('location').value = hallLocation;
    document.getElementById('capacity').value = hallCapacity.replace(' people', '');
    
    // Store the card reference
    modal.dataset.editingCard = card.id;
    
    // Update form submit handler
    const form = document.getElementById('addHallForm');
    form.onsubmit = function(e) {
        e.preventDefault();
        
        // Get the card being edited
        const cardToUpdate = document.getElementById(modal.dataset.editingCard);
        
        // Update card with new values
        cardToUpdate.querySelector('.hall-name').textContent = document.getElementById('hallName').value;
        cardToUpdate.querySelector('.hall-type').textContent = document.getElementById('hallType').value;
        cardToUpdate.querySelector('.hall-price').textContent = '₹' + document.getElementById('price').value + '/hr';
        cardToUpdate.querySelector('.hall-location span').textContent = document.getElementById('location').value;
        cardToUpdate.querySelector('.hall-capacity span').textContent = document.getElementById('capacity').value + ' people';
        
        // Update the data-hall-type attribute
        cardToUpdate.setAttribute('data-hall-type', document.getElementById('hallType').value);
        
        // Close modal
        modal.style.display = 'none';
        
        // Reset form
        form.reset();
        
        // Remove the editing card reference
        delete modal.dataset.editingCard;
    };
}

// Function to delete a hall
function deleteHall(button) {
    if (confirm('Are you sure you want to delete this hall?')) {
        const card = button.closest('.hall-card');
        card.remove();
    }
}

// Function to view hall details
function viewHall(button) {
    const card = button.closest('.hall-card');
    // Implement view functionality here
    alert('Viewing hall details: ' + card.querySelector('.hall-name').textContent);
}

// Function to show add hall form
function showAddHallForm() {
    const modal = document.getElementById('addHallModal');
    modal.style.display = 'block';
}

// Function to close modal
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    initializeCharts();

    // Add click handlers to category tabs
    const categoryButtons = document.querySelectorAll('.category-tab');
    
    categoryButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const selectedCategory = this.textContent.trim();
            filterHalls(selectedCategory);
        });
    });

    // Set default filter to show all halls
    filterHalls('All Venues');

    // Add event listeners for modals
    document.querySelectorAll('.close').forEach(closeButton => {
        closeButton.addEventListener('click', function() {
            const modal = this.closest('.modal');
            modal.style.display = 'none';
        });
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
});

// ... existing code ...

// Initialize charts when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Initialize weekly bookings chart
    const weeklyBookingsCtx = document.getElementById('weeklyBookingsChart').getContext('2d');
    const weeklyBookingsChart = new Chart(weeklyBookingsCtx, {
        type: 'bar',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Bookings',
                data: [12, 19, 3, 5, 2, 3, 7],
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Initialize monthly revenue chart
    const monthlyRevenueCtx = document.getElementById('monthlyRevenueChart').getContext('2d');
    const monthlyRevenueChart = new Chart(monthlyRevenueCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            datasets: [{
                label: 'Revenue',
                data: [12000, 19000, 3000, 5000, 2000, 3000, 7000, 10000, 15000, 20000, 25000, 30000],
                fill: false,
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Initialize hall cards
    initializeHallCards();
});

// Function to initialize hall cards
function initializeHallCards() {
    const hallCards = document.querySelectorAll('.hall-card');
    hallCards.forEach(card => {
        const editButton = card.querySelector('.edit-button');
        const deleteButton = card.querySelector('.delete-button');
        const viewButton = card.querySelector('.view-button');

        if (editButton) {
            editButton.addEventListener('click', () => editHall(editButton));
        }
        if (deleteButton) {
            deleteButton.addEventListener('click', () => deleteHall(deleteButton));
        }
        if (viewButton) {
            viewButton.addEventListener('click', () => viewHall(viewButton));
        }
    });
}

// Function to handle hall deletion
function deleteHall(button) {
    if (confirm('Are you sure you want to delete this hall?')) {
        const card = button.closest('.hall-card');
        card.remove();
    }
}

// Function to handle hall viewing
function viewHall(button) {
    const card = button.closest('.hall-card');
    const hallName = card.querySelector('.hall-name').textContent;
    const hallType = card.querySelector('.hall-type').textContent;
    const hallPrice = card.querySelector('.hall-price').textContent;
    const hallLocation = card.querySelector('.hall-location span').textContent;
    const hallCapacity = card.querySelector('.hall-capacity span').textContent;

    alert(`Hall Details:\n\nName: ${hallName}\nType: ${hallType}\nPrice: ${hallPrice}\nLocation: ${hallLocation}\nCapacity: ${hallCapacity}`);
}

// ... existing code ...

// Handle admin profile click to redirect to settings
document.addEventListener('DOMContentLoaded', function() {
    const adminProfile = document.querySelector('.admin-profile');
    if (adminProfile) {
        adminProfile.addEventListener('click', function() {
            // Hide all sections
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Show settings section
            const settingsSection = document.getElementById('settings');
            if (settingsSection) {
                settingsSection.classList.add('active');
                
                // Activate profile tab in settings
                const profileTab = document.querySelector('.settings-tab[data-tab="profile"]');
                if (profileTab) {
                    profileTab.click();
                }
            }
        });
    }
});

// ... existing code ...

// Update the hall type options in the form
document.addEventListener('DOMContentLoaded', function() {
    const hallTypeSelect = document.getElementById('hallType');
    if (hallTypeSelect) {
        hallTypeSelect.innerHTML = `
            <option value="Wedding">Wedding Hall</option>
            <option value="Conference">Conference Hall</option>
            <option value="Party">Party</option>
            <option value="Rooftop">Rooftop Hall</option>
        `;
    }
});

// ... existing code ...

// Maintenance Request Filtering
document.addEventListener('DOMContentLoaded', function() {
    // Get all filter elements
    const statusFilter = document.getElementById('status-filter');
    const hallFilter = document.getElementById('hall-filter');
    const priorityFilter = document.getElementById('priority-filter');
    const searchInput = document.querySelector('.maintenance-filters .search-input input');

    // Function to filter maintenance requests
    function filterMaintenanceRequests() {
        const selectedStatus = statusFilter.value;
        const selectedHall = hallFilter.value;
        const selectedPriority = priorityFilter.value;
        const searchTerm = searchInput.value.toLowerCase();

        // Get all request items
        const requestItems = document.querySelectorAll('.request-item');

        requestItems.forEach(item => {
            const status = item.querySelector('.status-badge').textContent.trim().toLowerCase();
            const hall = item.querySelector('td:nth-child(2)').textContent.trim().toLowerCase();
            const priority = item.querySelector('.priority-badge').textContent.trim().toLowerCase();
            const title = item.querySelector('td:nth-child(3)').textContent.trim().toLowerCase();
            const submittedBy = item.querySelector('td:nth-child(4)').textContent.trim().toLowerCase();

            // Check if hall is one of the allowed types
            const allowedHalls = ['wedding', 'conference', 'party', 'rooftop'];
            const isAllowedHall = allowedHalls.some(allowedHall => hall.includes(allowedHall));

            // Check if item matches all filters
            const matchesStatus = selectedStatus === 'all' || status.includes(selectedStatus);
            const matchesHall = selectedHall === 'all' ? isAllowedHall : hall.includes(selectedHall.toLowerCase());
            const matchesPriority = selectedPriority === 'all' || priority.includes(selectedPriority);
            const matchesSearch = searchTerm === '' || 
                title.includes(searchTerm) || 
                submittedBy.includes(searchTerm) ||
                hall.includes(searchTerm);

            // Show/hide based on filter matches and allowed halls
            if (matchesStatus && matchesHall && matchesPriority && matchesSearch && isAllowedHall) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });

        // Update stats based on visible items
        updateMaintenanceStats();
    }

    // Function to update maintenance stats
    function updateMaintenanceStats() {
        const visibleRequests = document.querySelectorAll('.request-item:not([style*="display: none"])');
        const pendingCount = Array.from(visibleRequests).filter(item => 
            item.querySelector('.status-badge').textContent.trim().toLowerCase().includes('pending')
        ).length;
        const inProgressCount = Array.from(visibleRequests).filter(item => 
            item.querySelector('.status-badge').textContent.trim().toLowerCase().includes('in progress')
        ).length;
        const completedCount = Array.from(visibleRequests).filter(item => 
            item.querySelector('.status-badge').textContent.trim().toLowerCase().includes('resolved')
        ).length;

        // Update stat numbers
        document.querySelector('.maintenance-stats .stat-card:nth-child(1) .stat-number').textContent = pendingCount;
        document.querySelector('.maintenance-stats .stat-card:nth-child(2) .stat-number').textContent = inProgressCount;
        document.querySelector('.maintenance-stats .stat-card:nth-child(3) .stat-number').textContent = completedCount;
    }

    // Add event listeners to all filters
    statusFilter.addEventListener('change', filterMaintenanceRequests);
    hallFilter.addEventListener('change', filterMaintenanceRequests);
    priorityFilter.addEventListener('change', filterMaintenanceRequests);
    searchInput.addEventListener('input', filterMaintenanceRequests);

    // Add animation for showing/hiding items
    const style = document.createElement('style');
    style.textContent = `
        .request-item {
            transition: all 0.3s ease;
        }
        .request-item[style*="display: none"] {
            opacity: 0;
            transform: translateX(-20px);
        }
        .request-item:not([style*="display: none"]) {
            opacity: 1;
            transform: translateX(0);
        }
    `;
    document.head.appendChild(style);
});

// ... existing code ...

// Maintenance Request Actions
function viewRequest(requestId) {
    // Get the request details
    const request = document.querySelector(`tr[data-request-id="${requestId}"]`);
    if (request) {
        // Show the request details modal
        const modal = document.getElementById('requestDetailsModal');
        modal.style.display = 'block';
        
        // Populate the modal with request details
        const details = {
            id: requestId,
            hall: request.querySelector('td:nth-child(2)').textContent,
            title: request.querySelector('td:nth-child(3)').textContent,
            submittedBy: request.querySelector('td:nth-child(4)').textContent,
            priority: request.getAttribute('data-priority'),
            status: request.querySelector('.status-badge').textContent.trim(),
            date: request.querySelector('td:nth-child(7)').textContent
        };
        
        // Update modal content
        document.querySelector('.request-details').innerHTML = `
            <div class="detail-item">
                <span class="detail-label">Request ID:</span>
                <span class="detail-value">${details.id}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Hall:</span>
                <span class="detail-value">${details.hall}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Title:</span>
                <span class="detail-value">${details.title}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Submitted By:</span>
                <span class="detail-value">${details.submittedBy}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Priority:</span>
                <span class="detail-value ${details.priority}">${details.priority}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Status:</span>
                <span class="detail-value">${details.status}</span>
            </div>
            <div class="detail-item">
                <span class="detail-label">Date:</span>
                <span class="detail-value">${details.date}</span>
            </div>
        `;
    }
}

function approveRequest(requestId) {
    if (confirm('Are you sure you want to approve this request?')) {
        const request = document.querySelector(`tr[data-request-id="${requestId}"]`);
        if (request) {
            // Update status badge
            const statusBadge = request.querySelector('.status-badge');
            statusBadge.innerHTML = '<i class="fas fa-check-circle"></i> Resolved';
            statusBadge.className = 'status-badge resolved';
            
            // Update action buttons to show only delete button
            const actionButtons = request.querySelector('.action-buttons');
            actionButtons.innerHTML = `
                <button class="action-btn delete" title="Delete Request" onclick="deleteRequest('${requestId}')">
                    <i class="fas fa-trash fa-fw"></i>
                </button>
            `;

            // Update maintenance stats
            updateMaintenanceStats();

            // Show success notification
            showNotification('Request approved successfully', 'success');

            // Close any open modals
            closeModal('requestDetailsModal');
        }
    }
}

function rejectRequest(requestId) {
    if (confirm('Are you sure you want to reject this request?')) {
        const request = document.querySelector(`tr[data-request-id="${requestId}"]`);
        if (request) {
            // Update status badge
            const statusBadge = request.querySelector('.status-badge');
            statusBadge.innerHTML = '<i class="fas fa-times-circle"></i> Rejected';
            statusBadge.className = 'status-badge rejected';
            
            // Show only delete button
            const actionButtons = request.querySelector('.action-buttons');
            actionButtons.innerHTML = `
                <button class="action-btn delete" onclick="deleteRequest('${requestId}')">
                    <i class="fas fa-trash fa-fw"></i>
                </button>
            `;
            
            // Show success message
            showNotification('Request rejected successfully!', 'success');
            
            // Update stats
            updateMaintenanceStats();
        }
    }
}

function deleteRequest(requestId) {
    if (confirm('Are you sure you want to delete this request? This action cannot be undone.')) {
        const request = document.querySelector(`tr[data-request-id="${requestId}"]`);
        if (request) {
            // Remove the request row
            request.remove();
            
            // Show success message
            showNotification('Request deleted successfully!', 'success');
            
            // Update stats
            updateMaintenanceStats();
        }
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    // Add to notifications container
    const container = document.querySelector('.notifications-container') || createNotificationsContainer();
    container.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function createNotificationsContainer() {
    const container = document.createElement('div');
    container.className = 'notifications-container';
    document.body.appendChild(container);
    return container;
}

function updateMaintenanceStats() {
    const stats = {
        pending: document.querySelectorAll('.status-badge.pending').length,
        inProgress: document.querySelectorAll('.status-badge.in-progress').length,
        resolved: document.querySelectorAll('.status-badge.resolved').length
    };
    
    // Update stats cards
    document.querySelector('.stat-card:nth-child(1) .stat-number').textContent = stats.pending;
    document.querySelector('.stat-card:nth-child(2) .stat-number').textContent = stats.inProgress;
    document.querySelector('.stat-card:nth-child(3) .stat-number').textContent = stats.resolved;
}

// ... existing code ...

// Update the initial action buttons in the HTML
document.addEventListener('DOMContentLoaded', function() {
    // Update all maintenance request rows to remove view button
    const maintenanceRows = document.querySelectorAll('.maintenance-table tbody tr');
    maintenanceRows.forEach(row => {
        const requestId = row.getAttribute('data-request-id');
        const actionButtons = row.querySelector('.action-buttons');
        if (actionButtons) {
            actionButtons.innerHTML = `
                <button class="action-btn approve" onclick="approveRequest('${requestId}')">
                    <i class="fas fa-check fa-fw"></i>
                </button>
                <button class="action-btn reject" onclick="rejectRequest('${requestId}')">
                    <i class="fas fa-times fa-fw"></i>
                </button>
                <button class="action-btn delete" onclick="deleteRequest('${requestId}')">
                    <i class="fas fa-trash fa-fw"></i>
                </button>
            `;
        }
    });
});

// ... existing code ...

function approveRefundWithNotification() {
    const requestId = document.getElementById('refund-id').textContent;
    const emailNotification = document.getElementById('email-notification').checked;
    const smsNotification = document.getElementById('sms-notification').checked;
    
    // Get refund details
    const refundDetails = {
        requestId: requestId,
        bookingId: document.getElementById('booking-id').textContent,
        customerName: document.getElementById('user-info').textContent,
        amount: document.getElementById('refund-amount').textContent,
        status: 'Approved'
    };

    // Send notifications if selected
    if (emailNotification) {
        sendEmailNotification(refundDetails);
    }
    if (smsNotification) {
        sendSMSNotification(refundDetails);
    }

    // Update refund status
    approveRefund(requestId);
    closeModal('refundDetailsModal');
}

function rejectRefundWithNotification() {
    const requestId = document.getElementById('refund-id').textContent;
    const emailNotification = document.getElementById('reject-email-notification').checked;
    const smsNotification = document.getElementById('reject-sms-notification').checked;
    const reason = document.getElementById('rejection-reason').value;
    
    // Get refund details
    const refundDetails = {
        requestId: requestId,
        bookingId: document.getElementById('booking-id').textContent,
        customerName: document.getElementById('user-info').textContent,
        amount: document.getElementById('refund-amount').textContent,
        status: 'Rejected',
        reason: reason
    };

    // Send notifications if selected
    if (emailNotification) {
        sendEmailNotification(refundDetails);
    }
    if (smsNotification) {
        sendSMSNotification(refundDetails);
    }

    // Update refund status
    rejectRefund(requestId, reason);
    closeModal('rejectRefundModal');
}

function sendEmailNotification(refundDetails) {
    // Replace placeholders in email template
    const emailSubject = `Refund Request Update - ${refundDetails.status}`;
    const emailBody = `
        Dear ${refundDetails.customerName},
        
        Your refund request for booking ${refundDetails.bookingId} has been ${refundDetails.status}.
        
        Details:
        - Request ID: ${refundDetails.requestId}
        - Amount: ${refundDetails.amount}
        - Status: ${refundDetails.status}
        ${refundDetails.reason ? `- Reason: ${refundDetails.reason}` : ''}
        
        Thank you for your patience.
    `;

    // Here you would integrate with your email service
    console.log('Sending email notification:', {
        to: 'customer@example.com', // Replace with actual customer email
        subject: emailSubject,
        body: emailBody
    });
}

function sendSMSNotification(refundDetails) {
    // Replace placeholders in SMS template
    const smsMessage = `
        Dear ${refundDetails.customerName}, 
        your refund request ${refundDetails.requestId} 
        for booking ${refundDetails.bookingId} 
        has been ${refundDetails.status}. 
        Amount: ${refundDetails.amount}.
        ${refundDetails.reason ? `Reason: ${refundDetails.reason}` : ''}
    `;

    // Here you would integrate with your SMS service
    console.log('Sending SMS notification:', {
        to: '+1234567890', // Replace with actual customer phone number
        message: smsMessage
    });
}

// ... existing code ...

function approveRefund(requestId) {
    if (confirm('Are you sure you want to approve this refund request?')) {
        const request = document.querySelector(`tr[data-request-id="${requestId}"]`);
        if (request) {
            // Get user email from the request row
            const userEmail = request.querySelector('td:nth-child(3)').textContent;
            const bookingId = request.querySelector('td:nth-child(2)').textContent;
            const amount = request.querySelector('td:nth-child(6)').textContent;

            // Update status badge
            const statusBadge = request.querySelector('.status-badge');
            statusBadge.innerHTML = '<i class="fas fa-check-circle"></i> Approved';
            statusBadge.className = 'status-badge approved';
            
            // Update action buttons to show only delete button
            const actionButtons = request.querySelector('.action-buttons');
            actionButtons.innerHTML = `
                <button class="action-btn delete" title="Delete Request" onclick="deleteRefund('${requestId}')">
                    <i class="fas fa-trash fa-fw"></i>
                </button>
            `;

            // Update refund stats
            updateRefundStats();

            // Send approval email
            sendRefundApprovalEmail(userEmail, requestId, bookingId, amount);

            // Show success notification
            showNotification('Refund request approved successfully and notification sent', 'success');

            // Close any open modals
            closeModal('refundDetailsModal');
        }
    }
}

function rejectRefund(requestId) {
    if (confirm('Are you sure you want to reject this refund request?')) {
        const request = document.querySelector(`tr[data-request-id="${requestId}"]`);
        if (request) {
            // Get user email from the request row
            const userEmail = request.querySelector('td:nth-child(3)').textContent;
            const bookingId = request.querySelector('td:nth-child(2)').textContent;
            const amount = request.querySelector('td:nth-child(6)').textContent;

            // Update status badge
            const statusBadge = request.querySelector('.status-badge');
            statusBadge.innerHTML = '<i class="fas fa-times-circle"></i> Rejected';
            statusBadge.className = 'status-badge rejected';
            
            // Update action buttons to show only delete button
            const actionButtons = request.querySelector('.action-buttons');
            actionButtons.innerHTML = `
                <button class="action-btn delete" title="Delete Request" onclick="deleteRefund('${requestId}')">
                    <i class="fas fa-trash fa-fw"></i>
                </button>
            `;

            // Update refund stats
            updateRefundStats();

            // Send rejection email
            sendRefundRejectionEmail(userEmail, requestId, bookingId, amount);

            // Show success notification
            showNotification('Refund request rejected and notification sent', 'success');

            // Close any open modals
            closeModal('refundDetailsModal');
        }
    }
}

function sendRefundApprovalEmail(userEmail, requestId, bookingId, amount) {
    const emailSubject = `Refund Request Approved - ${requestId}`;
    const emailBody = `
        Dear Customer,

        Your refund request has been approved.

        Request Details:
        - Request ID: ${requestId}
        - Booking ID: ${bookingId}
        - Amount: ${amount}

        The refund amount will be processed and credited to your original payment method within 5-7 business days.

        If you have any questions, please contact our support team.

        Best regards,
        Hall Management System
    `;

    // Here you would integrate with your email service
    // For example, using a service like SendGrid, Mailgun, or your own email server
    console.log('Sending approval email to:', userEmail);
    console.log('Subject:', emailSubject);
    console.log('Body:', emailBody);

    // TODO: Implement actual email sending logic here
    // Example: sendEmail(userEmail, emailSubject, emailBody);
}

function sendRefundRejectionEmail(userEmail, requestId, bookingId, amount) {
    const emailSubject = `Refund Request Rejected - ${requestId}`;
    const emailBody = `
        Dear Customer,

        We regret to inform you that your refund request has been rejected.

        Request Details:
        - Request ID: ${requestId}
        - Booking ID: ${bookingId}
        - Amount: ${amount}

        If you believe this is an error or would like to appeal this decision, please contact our support team.

        Best regards,
        Hall Management System
    `;

    // Here you would integrate with your email service
    console.log('Sending rejection email to:', userEmail);
    console.log('Subject:', emailSubject);
    console.log('Body:', emailBody);

    // TODO: Implement actual email sending logic here
    // Example: sendEmail(userEmail, emailSubject, emailBody);
}

// ... existing code ...

function updateRefundStats() {
    const totalRefunds = document.querySelectorAll('.refund-table tbody tr').length;
    const pendingRefunds = document.querySelectorAll('.status-badge.pending').length;
    const approvedRefunds = document.querySelectorAll('.status-badge.approved').length;
    const rejectedRefunds = document.querySelectorAll('.status-badge.rejected').length;

    // Update the stats cards
    document.querySelector('.refund-stats .stat-card:nth-child(1) .stat-number').textContent = totalRefunds;
    document.querySelector('.refund-stats .stat-card:nth-child(2) .stat-number').textContent = pendingRefunds;
    document.querySelector('.refund-stats .stat-card:nth-child(3) .stat-number').textContent = approvedRefunds;
    document.querySelector('.refund-stats .stat-card:nth-child(4) .stat-number').textContent = rejectedRefunds;
}

// ... existing code ...

// ... existing code ...

function initializeRefundFilters() {
    const statusFilter = document.getElementById('status-filter');
    const dateRangeFilter = document.getElementById('date-range');
    const searchInput = document.querySelector('.refund-filters .search-input input');

    // Add event listeners for filters
    statusFilter.addEventListener('change', filterRefundRequests);
    dateRangeFilter.addEventListener('change', filterRefundRequests);
    searchInput.addEventListener('input', filterRefundRequests);
}

function filterRefundRequests() {
    const statusFilter = document.getElementById('status-filter').value.toLowerCase();
    const dateRange = document.getElementById('date-range').value;
    const searchQuery = document.querySelector('.search-input input').value.toLowerCase();
    const table = document.getElementById('refundTable');
    const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    let visibleCount = 0;

    // First, hide all rows
    for (let row of rows) {
        row.style.display = 'none';
    }

    // Then show only matching rows
    for (let row of rows) {
        const statusCell = row.querySelector('td:nth-child(8)');
        const requestDateCell = row.querySelector('td:nth-child(9)');
        const bookingIdCell = row.querySelector('td:nth-child(2)');
        const userCell = row.querySelector('td:nth-child(3)');
        const hallCell = row.querySelector('td:nth-child(4)');
        const reasonCell = row.querySelector('td:nth-child(7)');

        let shouldShow = true;

        // Status filter
        if (statusFilter !== 'all' && statusCell.textContent.toLowerCase() !== statusFilter) {
            shouldShow = false;
        }

        // Date range filter
        if (dateRange !== 'all') {
            const requestDate = new Date(requestDateCell.textContent);
            const today = new Date();
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay());
            const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

            switch (dateRange) {
                case 'today':
                    if (requestDate.toDateString() !== today.toDateString()) {
                        shouldShow = false;
                    }
                    break;
                case 'week':
                    if (requestDate < startOfWeek) {
                        shouldShow = false;
                    }
                    break;
                case 'month':
                    if (requestDate < startOfMonth) {
                        shouldShow = false;
                    }
                    break;
            }
        }

        // Search filter
        if (searchQuery) {
            const searchableText = [
                bookingIdCell.textContent,
                userCell.textContent,
                hallCell.textContent,
                reasonCell.textContent
            ].join(' ').toLowerCase();

            if (!searchableText.includes(searchQuery)) {
                shouldShow = false;
            }
        }

        // Show/hide row based on filters
        if (shouldShow) {
            row.style.display = '';
            visibleCount++;
        }
    }

    // Show "No results" message if no rows are visible
    const tbody = table.getElementsByTagName('tbody')[0];
    const existingNoResults = tbody.querySelector('.no-results');
    if (existingNoResults) {
        existingNoResults.remove();
    }

    if (visibleCount === 0) {
        const noResultsRow = document.createElement('tr');
        noResultsRow.classList.add('no-results');
        noResultsRow.innerHTML = `
            <td colspan="10" style="text-align: center; padding: 20px;">
                No refund requests found matching the selected filters.
            </td>
        `;
        tbody.appendChild(noResultsRow);
    }

    // Update stats based on visible rows
    updateRefundStats();
}

function updateRefundStats() {
    const table = document.getElementById('refundTable');
    const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    let total = 0;
    let pending = 0;
    let approved = 0;
    let rejected = 0;

    for (let row of rows) {
        if (row.style.display !== 'none' && !row.classList.contains('no-results')) {
            const statusCell = row.querySelector('td:nth-child(8)');
            const status = statusCell.textContent.toLowerCase();
            
            total++;
            switch (status) {
                case 'pending':
                    pending++;
                    break;
                case 'approved':
                    approved++;
                    break;
                case 'rejected':
                    rejected++;
                    break;
            }
        }
    }

    // Update stat cards
    document.querySelector('.refund-stats .stat-card:nth-child(1) .stat-number').textContent = total;
    document.querySelector('.refund-stats .stat-card:nth-child(2) .stat-number').textContent = pending;
    document.querySelector('.refund-stats .stat-card:nth-child(3) .stat-number').textContent = approved;
    document.querySelector('.refund-stats .stat-card:nth-child(4) .stat-number').textContent = rejected;
}

// Initialize filters
function initializeRefundFilters() {
    const statusFilter = document.getElementById('status-filter');
    const dateRange = document.getElementById('date-range');
    const searchInput = document.querySelector('.search-input input');

    statusFilter.addEventListener('change', filterRefundRequests);
    dateRange.addEventListener('change', filterRefundRequests);
    searchInput.addEventListener('input', filterRefundRequests);

    // Set default date range to "All Time"
    dateRange.value = 'all';
    
    // Trigger initial filtering
    filterRefundRequests();
}

// Call initializeRefundFilters when the page loads
document.addEventListener('DOMContentLoaded', initializeRefundFilters);

// ... existing code ...

// Sample refund request data
const refundRequests = [
    {
        id: 'REF-2024-001',
        bookingId: 'BK-2024-001',
        userName: 'John Doe',
        userEmail: 'john.doe@example.com',
        userPhone: '+1234567890',
        hallName: 'Grand Wedding Hall',
        bookingDate: '2024-03-15',
        amount: 15000,
        reason: 'Event cancelled due to personal reasons',
        status: 'Pending',
        requestDate: '2024-03-10',
        paymentMethod: 'Credit Card',
        transactionId: 'TXN-001',
        adminNotes: '',
        statusLogs: [
            {
                date: '2024-03-10',
                status: 'Pending',
                note: 'Refund request submitted'
            }
        ]
    },
    {
        id: 'REF-2024-002',
        bookingId: 'BK-2024-002',
        userName: 'Jane Smith',
        userEmail: 'jane.smith@example.com',
        userPhone: '+1987654321',
        hallName: 'Corporate Conference Center',
        bookingDate: '2024-03-20',
        amount: 8000,
        reason: 'Company event postponed to next quarter',
        status: 'Approved',
        requestDate: '2024-03-05',
        paymentMethod: 'Bank Transfer',
        transactionId: 'TXN-002',
        adminNotes: 'Approved after verification of company policy',
        statusLogs: [
            {
                date: '2024-03-05',
                status: 'Pending',
                note: 'Refund request submitted'
            },
            {
                date: '2024-03-07',
                status: 'Approved',
                note: 'Request approved by admin'
            }
        ]
    },
    {
        id: 'REF-2024-003',
        bookingId: 'BK-2024-003',
        userName: 'Robert Johnson',
        userEmail: 'robert.j@example.com',
        userPhone: '+1122334455',
        hallName: 'Birthday Party Hall',
        bookingDate: '2024-03-25',
        amount: 5000,
        reason: 'Found a better venue',
        status: 'Rejected',
        requestDate: '2024-03-08',
        paymentMethod: 'Credit Card',
        transactionId: 'TXN-003',
        adminNotes: 'Rejected as per cancellation policy - within 14 days of event',
        statusLogs: [
            {
                date: '2024-03-08',
                status: 'Pending',
                note: 'Refund request submitted'
            },
            {
                date: '2024-03-09',
                status: 'Rejected',
                note: 'Request rejected due to policy violation'
            }
        ]
    },
    {
        id: 'REF-2024-004',
        bookingId: 'BK-2024-004',
        userName: 'Sarah Williams',
        userEmail: 'sarah.w@example.com',
        userPhone: '+1555666777',
        hallName: 'Wedding Reception Hall',
        bookingDate: '2024-04-01',
        amount: 20000,
        reason: 'Change in wedding date',
        status: 'Pending',
        requestDate: '2024-03-12',
        paymentMethod: 'Bank Transfer',
        transactionId: 'TXN-004',
        adminNotes: '',
        statusLogs: [
            {
                date: '2024-03-12',
                status: 'Pending',
                note: 'Refund request submitted'
            }
        ]
    },
    {
        id: 'REF-2024-005',
        bookingId: 'BK-2024-005',
        userName: 'Michael Brown',
        userEmail: 'michael.b@example.com',
        userPhone: '+1444555666',
        hallName: 'Corporate Meeting Room',
        bookingDate: '2024-03-28',
        amount: 3000,
        reason: 'Meeting cancelled due to company restructuring',
        status: 'Approved',
        requestDate: '2024-03-15',
        paymentMethod: 'Credit Card',
        transactionId: 'TXN-005',
        adminNotes: 'Approved with documentation of company restructuring',
        statusLogs: [
            {
                date: '2024-03-15',
                status: 'Pending',
                note: 'Refund request submitted'
            },
            {
                date: '2024-03-16',
                status: 'Approved',
                note: 'Request approved with supporting documents'
            }
        ]
    },
    {
        id: 'REF-2024-006',
        bookingId: 'BK-2024-006',
        userName: 'Emily Davis',
        userEmail: 'emily.d@example.com',
        userPhone: '+1777888999',
        hallName: 'Anniversary Celebration Hall',
        bookingDate: '2024-04-05',
        amount: 12000,
        reason: 'Family emergency',
        status: 'Rejected',
        requestDate: '2024-03-18',
        paymentMethod: 'Bank Transfer',
        transactionId: 'TXN-006',
        adminNotes: 'Rejected - within 7 days of event, non-refundable as per policy',
        statusLogs: [
            {
                date: '2024-03-18',
                status: 'Pending',
                note: 'Refund request submitted'
            },
            {
                date: '2024-03-19',
                status: 'Rejected',
                note: 'Request rejected due to late cancellation'
            }
        ]
    },
    {
        id: 'REF-2024-007',
        bookingId: 'BK-2024-007',
        userName: 'David Wilson',
        userEmail: 'david.w@example.com',
        userPhone: '+1666777888',
        hallName: 'Graduation Party Hall',
        bookingDate: '2024-04-10',
        amount: 7000,
        reason: 'Change in graduation ceremony date',
        status: 'Pending',
        requestDate: '2024-03-20',
        paymentMethod: 'Credit Card',
        transactionId: 'TXN-007',
        adminNotes: '',
        statusLogs: [
            {
                date: '2024-03-20',
                status: 'Pending',
                note: 'Refund request submitted'
            }
        ]
    },
    {
        id: 'REF-2024-008',
        bookingId: 'BK-2024-008',
        userName: 'Lisa Anderson',
        userEmail: 'lisa.a@example.com',
        userPhone: '+1888999000',
        hallName: 'Product Launch Venue',
        bookingDate: '2024-04-15',
        amount: 25000,
        reason: 'Product launch postponed to next quarter',
        status: 'Approved',
        requestDate: '2024-03-22',
        paymentMethod: 'Bank Transfer',
        transactionId: 'TXN-008',
        adminNotes: 'Approved with company documentation',
        statusLogs: [
            {
                date: '2024-03-22',
                status: 'Pending',
                note: 'Refund request submitted'
            },
            {
                date: '2024-03-23',
                status: 'Approved',
                note: 'Request approved with company letter'
            }
        ]
    }
];

// Function to format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
}

// Function to format date
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

// Function to render refund requests table
function renderRefundRequests() {
    const tbody = document.querySelector('#refundTable tbody');
    if (!tbody) {
        console.error('Refund table body not found');
        return;
    }
    
    tbody.innerHTML = '';

    refundRequests.forEach(request => {
        const row = document.createElement('tr');
        row.setAttribute('data-request-id', request.id);
        row.innerHTML = `
            <td>${request.id}</td>
            <td>${request.bookingId}</td>
            <td>
                <div>${request.userName}</div>
                <small class="text-muted">${request.userEmail}</small>
            </td>
            <td>${request.hallName}</td>
            <td>${formatDate(request.bookingDate)}</td>
            <td>${formatCurrency(request.amount)}</td>
            <td>${request.reason}</td>
            <td>
                <span class="status-badge ${request.status.toLowerCase()}">
                    ${request.status}
                </span>
            </td>
            <td>${formatDate(request.requestDate)}</td>
            <td>
                <div class="action-buttons">
                    ${request.status === 'Pending' ? `
                        <button class="action-btn approve" onclick="approveRefund('${request.id}')">
                            <i class="fas fa-check fa-fw"></i>
                        </button>
                        <button class="action-btn reject" onclick="rejectRefund('${request.id}')">
                            <i class="fas fa-times fa-fw"></i>
                        </button>
                    ` : ''}
                    <button class="action-btn delete" onclick="deleteRefund('${request.id}')">
                        <i class="fas fa-trash fa-fw"></i>
                    </button>
                </div>
            </td>
        `;
        tbody.appendChild(row);
    });

    updateRefundStats();
}

// Function to filter refund requests
function filterRefundRequests() {
    const statusFilter = document.getElementById('status-filter').value;
    const dateFrom = document.getElementById('date-from').value;
    const dateTo = document.getElementById('date-to').value;
    const searchQuery = document.getElementById('refund-search').value.toLowerCase();

    const rows = document.querySelectorAll('#refundTable tbody tr');
    let visibleCount = 0;

    rows.forEach(row => {
        const status = row.querySelector('.status-badge').textContent.trim().toLowerCase();
        const requestDate = row.querySelector('td:nth-child(9)').textContent;
        const bookingId = row.querySelector('td:nth-child(2)').textContent;
        const userEmail = row.querySelector('td:nth-child(3) small').textContent;
        const hallName = row.querySelector('td:nth-child(4)').textContent;
        
        let shouldShow = true;

        // Apply status filter
        if (statusFilter !== 'all' && status !== statusFilter) {
            shouldShow = false;
        }

        // Apply date range filter
        if (dateFrom && dateTo) {
            const requestDateObj = new Date(requestDate);
            const fromDate = new Date(dateFrom);
            const toDate = new Date(dateTo);
            toDate.setHours(23, 59, 59, 999); // Include the entire end date
            
            if (requestDateObj < fromDate || requestDateObj > toDate) {
                shouldShow = false;
            }
        }

        // Apply search filter
        if (searchQuery) {
            const searchableText = [
                bookingId,
                userEmail,
                hallName,
                row.querySelector('td:nth-child(1)').textContent, // Request ID
                row.querySelector('td:nth-child(7)').textContent  // Reason
            ].join(' ').toLowerCase();
            
            if (!searchableText.includes(searchQuery)) {
                shouldShow = false;
            }
        }

        // Show/hide row
        row.style.display = shouldShow ? '' : 'none';
        if (shouldShow) visibleCount++;
    });

    // Show "No results" message if no rows are visible
    const tbody = document.querySelector('#refundTable tbody');
    let noResultsRow = tbody.querySelector('.no-results-row');
    
    if (visibleCount === 0) {
        if (!noResultsRow) {
            noResultsRow = document.createElement('tr');
            noResultsRow.className = 'no-results-row';
            noResultsRow.innerHTML = `
                <td colspan="10" class="text-center py-4">
                    <div class="text-muted">
                        <i class="fas fa-search fa-2x mb-3"></i>
                        <p>No refund requests found matching your criteria</p>
                    </div>
                </td>
            `;
            tbody.appendChild(noResultsRow);
        }
    } else if (noResultsRow) {
        noResultsRow.remove();
    }

    // Update stats based on visible rows
    updateRefundStats();
}

// Update refund stats based on visible rows
function updateRefundStats() {
    const visibleRows = document.querySelectorAll('#refundTable tbody tr:not([style*="display: none"])');
    const totalRefunds = visibleRows.length;
    const pendingRefunds = document.querySelectorAll('#refundTable .status-badge.pending:not([style*="display: none"])').length;
    const approvedRefunds = document.querySelectorAll('#refundTable .status-badge.approved:not([style*="display: none"])').length;
    const rejectedRefunds = document.querySelectorAll('#refundTable .status-badge.rejected:not([style*="display: none"])').length;

    // Update the stats cards
    document.querySelector('.refund-stats .stat-card:nth-child(1) .stat-number').textContent = totalRefunds;
    document.querySelector('.refund-stats .stat-card:nth-child(2) .stat-number').textContent = pendingRefunds;
    document.querySelector('.refund-stats .stat-card:nth-child(3) .stat-number').textContent = approvedRefunds;
    document.querySelector('.refund-stats .stat-card:nth-child(4) .stat-number').textContent = rejectedRefunds;
}

// Initialize refund filters
function initializeRefundFilters() {
    const statusFilter = document.getElementById('status-filter');
    const dateFrom = document.getElementById('date-from');
    const dateTo = document.getElementById('date-to');
    const searchInput = document.getElementById('refund-search');

    // Add event listeners for filters
    statusFilter.addEventListener('change', filterRefundRequests);
    dateFrom.addEventListener('change', filterRefundRequests);
    dateTo.addEventListener('change', filterRefundRequests);
    searchInput.addEventListener('input', filterRefundRequests);

    // Set default date range to last 30 days
    const today = new Date();
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(today.getDate() - 30);
    
    dateFrom.value = thirtyDaysAgo.toISOString().split('T')[0];
    dateTo.value = today.toISOString().split('T')[0];

    // Trigger initial filter
    filterRefundRequests();
}

// Initialize refund section
function initializeRefundSection() {
    renderRefundRequests();
    initializeRefundFilters();
}

// Call initialization when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeRefundSection();
});

function updatePaymentStats() {
    const table = document.getElementById('transactions-list');
    const rows = table.getElementsByTagName('tr');
    let total = 0;
    let completed = 0;
    let pending = 0;
    let refunded = 0;
    let totalAmount = 0;

    for (let row of rows) {
        if (row.style.display !== 'none' && !row.classList.contains('no-results')) {
            const statusCell = row.querySelector('.payment-status');
            const amountCell = row.querySelector('td:nth-child(5)');
            const status = statusCell.textContent.trim().toLowerCase();
            const amount = parseFloat(amountCell.textContent.replace(/[^0-9.-]+/g, ''));
            
            total++;
            totalAmount += amount;
            
            switch (status) {
                case 'completed':
                    completed++;
                    break;
                case 'pending':
                    pending++;
                    break;
                case 'refunded':
                    refunded++;
                    break;
            }
        }
    }

    // Update stat cards
    document.querySelector('.payment-stats .stat-card:nth-child(1) .stat-number').textContent = formatCurrency(totalAmount);
    document.querySelector('.payment-stats .stat-card:nth-child(2) .stat-number').textContent = completed;
    document.querySelector('.payment-stats .stat-card:nth-child(3) .stat-number').textContent = pending;
    document.querySelector('.payment-stats .stat-card:nth-child(4) .stat-number').textContent = formatCurrency(totalAmount / (total || 1));
}

function initializePaymentFilters() {
    const statusFilter = document.getElementById('payment-filter');
    const searchInput = document.getElementById('transaction-search');

    statusFilter.addEventListener('change', () => filterTransactions(statusFilter.value));
    searchInput.addEventListener('input', () => filterTransactions(statusFilter.value));

    // Set default filter to "All Transactions"
    statusFilter.value = 'all';
    
    // Trigger initial filtering
    filterTransactions('all');
}

// Call initializePaymentFilters when the page loads
document.addEventListener('DOMContentLoaded', initializePaymentFilters);