let start = document.getElementById("start");
let home = document.getElementById('home-page');
let test = document.getElementById('test');
let question = document.getElementById('questions');
let previous = document.getElementById('prev');
let next = document.getElementById('next');
let submit = document.getElementById('submit');
let final = document.getElementById('submit-page');
let result = document.getElementById('result');
let timer = document.getElementById('timer');
let index = 0;
let score = 0;


let query = [
  {
    "question": "What is the capital of France?",
    "options": ["Berlin", "Madrid", "Paris", "Rome"],
    "answer": "Paris",
    "userAnswer": null
  },
  {
    "question": "Which planet is known as the Red Planet?",
    "options": ["Mars", "Jupiter", "Venus", "Saturn"],
    "answer": "Mars",
    "userAnswer": null
  },
  {
    "question": "What is the largest ocean on Earth?",
    "options": ["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
    "answer": "Pacific Ocean",
    "userAnswer": null
  },
  {
    "question": "In which year did the Titanic sink?",
    "options": ["1912", "1905", "1920", "1915"],
    "answer": "1912",
    "userAnswer": null
  },
  {
    "question": "What is the smallest country in the world?",
    "options": ["Monaco", "Nauru", "Vatican City", "San Marino"],
    "answer": "Vatican City",
    "userAnswer": null
  },
  {
    "question": "Who painted the Mona Lisa?",
    "options": ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Claude Monet"],
    "answer": "Leonardo da Vinci",
    "userAnswer": null
  },
  {
    "question": "What is the currency of Japan?",
    "options": ["Yuan", "Won", "Yen", "Dollar"],
    "answer": "Yen",
    "userAnswer": null
  },
  {
    "question": "How many continents are there?",
    "options": ["5", "6", "7", "8"],
    "answer": "7",
    "userAnswer": null
  },
  {
    "question": "What is the chemical symbol for gold?",
    "options": ["Au", "Ag", "Fe", "Pb"],
    "answer": "Au",
    "userAnswer": null
  },
  {
    "question": "Which animal is the king of the jungle?",
    "options": ["Tiger", "Lion", "Elephant", "Bear"],
    "answer": "Lion",
    "userAnswer": null
  }
]

let seconds = 59;
let minutes = query.length - 1;

// let seconds = 10;
// let minutes = 0;

function remark(choose){
  // alert(index);
  query[index].userAnswer = choose;
}

// alert(index++)
start.onclick = function(){
  creation(index);
  home.style.display = 'none';
  test.style.display = 'block';

  let uid = setInterval(function(){
    seconds -= 1;
    timer.textContent = (minutes < 10 ? "0" + minutes.toString() : minutes) + ":" + (seconds < 10 ? '0' + seconds.toString() : seconds);
    if(seconds < 0 && minutes !== 0){
      seconds = 59;
      minutes -= 1;
    }
    if (minutes === 0 && seconds === 0){
      clearInterval(uid);
      test.style.display = 'none';
      finalResult();
    }
  }, 1000)

  next.onclick = function(){
    creation(++index);
  }

  previous.onclick = function(){
    creation(--index);
  }

  function creation(index){ 
  question.innerHTML = '';
  if (index === 0){
    previous.style.display = 'none';
  }
  else{
    previous.style.display = 'block';
  }

  if (index === query.length - 1){
    next.style.display = 'none';
    submit.style.display = 'block';
  }
  else{
    next.style.display = 'block';
    submit.style.display = 'none';
  }

  let head = document.createElement('h3');
  let num = index;
  head.textContent = (num + 1) + ') ' + query[index].question;
  question.appendChild(head)

  let div = document.createElement('div');
  div.classList.add('choose');
  question.appendChild(div)

  for (let opp in query[index].options) {
    let label = document.createElement('label');
    label.setAttribute('for', query[index].options[opp]);
    div.appendChild(label);
        
    let input = document.createElement('input');
    input.type = 'radio';
    input.setAttribute('onclick', `remark('${query[index].options[opp]}')`);
    input.name = query[index].answer;
    input.id = query[index].options[opp];
    if (query[index].userAnswer === query[index].options[opp]){
      input.checked = true;
    }
    label.appendChild(input);
        
    const text = document.createTextNode(query[index].options[opp]);
    label.appendChild(text);        
    };      
  }
}

function finalResult(){
  test.style.display = 'none';
  final.style.display = 'flex';
  for(let e of query){
    if (e.answer == e.userAnswer){
      score++;
    }
  }
  result.textContent = score + '/' + query.length;
}


submit.addEventListener('click', finalResult);


