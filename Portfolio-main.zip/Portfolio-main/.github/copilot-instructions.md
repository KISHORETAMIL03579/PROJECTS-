# Copilot Instructions for Portfolio Codebase

## Overview
This is a personal portfolio project consisting of static files: `index.html`, `style.css`, and assets like images and PDFs. The project is designed for a simple, visually appealing web presence with a custom color palette and responsive design.

## Key Files
- `index.html`: Main HTML structure for the portfolio site.
- `style.css`: Custom styles, including responsive navigation, color themes, and animation effects.
- `Nagendhiran.jpg`, `Resume_2025.pdf`: Static assets for profile and resume.

## Architecture & Patterns
- **No frameworks**: Pure HTML and CSS, no JavaScript or build tools.
- **Custom color palette**: Colors are defined in `README.md` and used throughout `style.css`.
- **Responsive design**: Uses flexbox, `clamp()` for font sizes, and media queries for adaptability.
- **Navigation bar**: Implemented with flexbox, custom hover effects, and button styling.
- **Animations**: Keyframes and CSS animations for text appearance.

## Developer Workflows
- **No build or test steps**: Edit files directly and open `index.html` in a browser to preview changes.
- **No package management**: All dependencies are static and local.
- **Debugging**: Use browser dev tools for layout and style debugging.

## Project Conventions
- **Class naming**: Semantic and descriptive (e.g., `.navbar`, `.home`, `.autoshow`).
- **Color usage**: Stick to the palette in `README.md` for consistency.
- **No inline styles**: All styling is in `style.css`.
- **No JavaScript**: All interactivity is CSS-based.

## Examples
- To add a new section, update `index.html` and style it in `style.css` using the existing class naming pattern.
- To change colors, update values in `style.css` to match the palette in `README.md`.

## Integration Points
- None: This project is fully static and self-contained.

---

For questions about project structure or conventions, see `README.md` or review `style.css` for implementation patterns.
