let inputText = document.getElementById("input-text");
let additem = document.getElementById("add-item");
let listItem = document.getElementById("list-items");

let id = 1;


additem.onclick = function() {
    let text = inputText.value.trim();
    
    if (text === ''){
        alert("Enter Valid Input");
        return;
    }
    let newid = id++;
    let checkedid = 'check' + parseInt(newid);
    let listid = 'list' + parseInt(newid);
    let labelid = 'label' + parseInt(newid);
    let deleteid = 'delete' + parseInt(newid);

        let li = document.createElement('li');
        li.id = listid;
        li.classList.add('item');
        listItem.appendChild(li);

        let div = document.createElement('div');
        li.appendChild(div);
        
        let input = document.createElement('input');
        input.type = 'checkbox';
        input.id = checkedid;
        div.appendChild(input);
        
        let label = document.createElement('label');
        label.id = labelid;
        label.classList.add('item-label')
        label.setAttribute('for', checkedid)
        label.textContent = text;
        div.appendChild(label)

        let i = document.createElement('i');
        i.classList.add('bx', 'bx-trash', 'delete');
        i.id = deleteid;
        li.appendChild(i);

        inputText.value = ''

        input.onclick = function() {
            completed(labelid);
        }

        i.onclick = function() {
            deleteItem(listid);
        }
 
}

function completed(labelid){
    let label = document.getElementById(labelid);
    label.classList.toggle('checked')

}

function deleteItem(deleteid){
    let item = document.getElementById(deleteid);
    listItem.removeChild(item);
}