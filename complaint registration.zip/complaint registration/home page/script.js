function showFormElements() {
    document.getElementById('formElements').style.display = 'block';
  }

  function hideFormElements() {
    document.getElementById('formElements').style.display = 'none';
  }
  function showElements() {
    document.getElementById('Elements').style.display = 'block';
  }

  function hideElements() {
    document.getElementById('Elements').style.display = 'none';
  }
 